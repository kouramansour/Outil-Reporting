<?php

session_cache_limiter('private_no_expire, must-revalidate');

require_once ('./Controleurs/ControleurUser/ControleurUser.php');

/**
 * This class ControleurAdmin allow to manage administrator's actions.
 * @extends ControleurUser because an administrator is a superuser.
 * @since 26 août 2016
 * @package ControleurAdmin
 * @author Jordan PROTIN <Jordan.Protin@yahoo.com>
 */
class ControleurAdmin extends ControleurUser
{
    /**
     * Class's constructor.
     *
     * @return Controleur[name] Call the good controller according action
     */
    function __construct() 
    {
        $_SESSION['page'] = "accueil";
        

        $tabErreur = array();

        //Verify if user is really administrator
    	if (!$_SESSION['usr_role'] == "Admin")
        { 
            header('Location:./'); 
        }

    	try
        {
            $action = Nettoyage::ClearString($_GET['action']);

           
            // Array which contains differents controller's name
            $arrayModule= array('TTimes','PostJob','Ordonnancement','JobOff','PlanAction','Affectation',
                                'PanneEvenement','DefautBlocage','GestionUtilisateur','Commun',
                                'Consigne', 'GestionUtilisateur', 'Sap');


            // Redirect user admin to the good sub controller according the route from the file FrontController.php
            foreach ($arrayModule as $module) {
            
                if($module != "GestionUtilisateur" && stripos($action, $module) !== false)
                {
                    parent::__construct(); //Call the ControleurUser's contructor here to manage actions
                }
                //User management is booked only administrator
                elseif($module == "GestionUtilisateur" && stripos($action, "GestionUtilisateur") !== false)
                {
                    new ControleurGestionUtilisateur();
                }
            }

            if($action == NULL)
            { 
                parent::afficherDashboardCommun(); 
                exit();
            }

            if($action == "")
            {
                $tabErreur[] = "<font color='red'>Erreur d'appel php | Pensez à supprimer vos cookies navigateur</font>";
                require('./Views/templates/Erreur/erreur.php');
                exit();
            }       		 
        }
        catch(PDOException $ExceptionErreurPDO)
        {
            $tabErreur[] = "<font color='red'>Erreur survenue sur la base de données. Veuillez contacter un administrateur !</font>";
            require('./Views/templates/Erreur/erreur.php');
        }
        catch(Exception $ExceptionErreur)
        {
            $tabErreur[] = "<font color='red'>Erreur inattendue sur le site. Veuillez contacter un administrateur</font>";
            require('./Views/templates/Erreur/erreur.php');
        }
    	exit(0);
    }

   
}
?>

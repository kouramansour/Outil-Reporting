﻿<?php

/**
 * Define all parameters which are necessary in order to connect to the remote database
 * @since 26 août 2016
 * @package Database
 * @author Jordan PROTIN <Jordan.Protin@yahoo.com>
 */

// HOST
define('DBHOST', '10.96.97.84');
// PORT
define('DBPORT', '');
// DATABASE'S NAME
define('DBNAME', 'reporting2016_dev');
// USERNAME
define('DBUSER', 'userTest');
// PASSWORD
define('DBPASS', 'pass');

date_default_timezone_set("Europe/paris");
setlocale(LC_ALL,'fr_FR.utf8', 'fra');
?>

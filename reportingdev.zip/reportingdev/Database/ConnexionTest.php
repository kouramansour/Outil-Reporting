<?php

/**
  * Call file config.php in order to get all parameters database
  */
include('configTest.php');

/**
 * This class Connexion allow to connect to the remote database
 * @extends PDO
 * @since 26 août 2016
 * @package Database
 * @author Jordan PROTIN <Jordan.Protin@yahoo.com>
 */
class Connexion extends PDO
{
  private $connexion;

  /**
   * Class's constructor's.
   *
   * @return Success or Error of try to connect to the remote database
   */
  public function __construct()
  {
      try
      {
        $dns = 'mysql:host='.DBHOST.';dbname='.DBNAME.'';
        $user = DBUSER;
        $password = DBPASS;
        $this->connexion = parent::__construct($dns, $user, $password, array(PDO::MYSQL_ATTR_INIT_COMMAND => 'SET NAMES \'UTF8\'')); 
        $dns = null;
      } 
      catch(PDOException $e)
      {
        echo "Erreur de connexion à la base de donéees : " .$dns. "<br><br>" . " Message : " .$e->getMessage(). " Code : " .$e->getCode(). "\r\n";
        die();
      }
  }

  /**
   * Prepare each request 
   * Function call from each file 'Mapper'
   * @version 1.1 
   * @author Steven MARTINS
   * @return Success or Error of execute request
   */
  public function executeQuery($query, array $parameters = [])
  {
    try
    {

      $stmt = $this->prepare($query);

      foreach ($parameters as $name => $value)
      {
        $stmt->bindValue(':' . $name, $value);
      }

	
      $stmt->execute();      
      return $stmt->fetchAll(PDO::FETCH_ASSOC);
    } 
    catch(Exception $e)
    {
       die('Erreur : '.$e->getMessage());
    }
  }

  /**
   * Prepare each request 
   * Function call from each file 'Mapper'
   * @version 1.2 
   * @author Jordan PROTIN
   * @return Success or Error of execute request
   */
  public function executeQueryNew($query, array $parameters = []) 
  {

      $stmt = $this->prepare($query);

      foreach ($parameters as $name => $value) 
      {
          $stmt->bindValue($name, $value);
      }
      return $stmt->execute();
  }

  /**
  * Prepare and execute each request 
  * @author Vanessa GONCALVES
  * @return Object of type $type
  */
  public function executeQueryReturnObject($query, $type)
  {
    try
    {
      $stmt = $this->prepare($query);

     

      $stmt->execute();      
      return $stmt->fetchAll(PDO::FETCH_CLASS, $type);
    } 
    catch(Exception $e)
    {
       die('Erreur : '.$e->getMessage());
    }
  }
}

?>

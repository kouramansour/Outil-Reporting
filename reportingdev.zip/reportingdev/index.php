<?php

//header('Location: http://10.96.98.72/reporting');
/**
 * First file called the launch of the application
 * >> ENTRY POINT APPLICATION <<
 * @since 26 août 2016
 * @package ./
 * @author Jordan PROTIN <Jordan.Protin@yahoo.com>
 */

    include("functions.php");
	/**
     * Autoloader called in order to indicate the project's architecture (each folders which are present)
     * @return function charger()
     */
	require_once(__DIR__.'/autoload.php');
	autoload::charger();

	/**
     * FrontController called in order to dispatch route action to the good subControllers
     * Important recall : First file called is ControleurVisiteur which play role entry point application
     * @return instantiate FrontController class
     */
	$cont = new FrontController();




?> 
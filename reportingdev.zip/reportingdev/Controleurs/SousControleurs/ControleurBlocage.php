<?php

session_cache_limiter('private_no_expire, must-revalidate');

/**
 * This class ControleurBlocage allow to manage all module blocage's actions.
 * @since 26 août 2016
 * @package SousControleurs
 * @author Jordan PROTIN <Jordan.Protin@yahoo.com> & Steven MARTINS
 */
class ControleurBlocage 
{

    /**
     * Class's constructor.
     *
     * @return Function[name] Call the good function according action
     */
    public function __construct()
    {
        $_SESSION['page'] = "blocage";
    	$tabErreur = array();
        $action = Nettoyage::ClearString($_GET['action']);

        //Check if the user has the necessary rights for this module
        if (!$_SESSION['usr_role'] == "Admin" || !$_SESSION['usr_role'] == "User")
        { 
            header('Location:./'); 
        }

        //By default, first $action called is 'afficherBlocageHistorique' or 'afficherBlocageSaisie'
        $this->$action(); 
        exit();	
    }

    /**
     * Allows a user to display the historical blockages page of the application.
     *
     * @return The historical blockages page
     */
    public function afficherBlocageHistorique()
    {
        require('./Views/templates/Blocage/BlocageHistorique.php');
    }

    /**
     * Allows a user to display the entry blockages page of the application.
     *
     * @return The entry blockages page
     */
    public function afficherBlocageSaisie()
    {
        require('./Views/templates/Blocage/BlocageSaisie.php');
    }

    /**
     * When a user wants to insert a recording in BDD's table Blocage.
     *
     * @return Function 'traiterVariablePost' after verification of user's identity
     */
    public function updateBlocage()
    {
        ob_start();

        if (isset($_SESSION['usr_loginmdp']))
        {
            //Action nothing if unknown user
        }
        else
        {
            header ('location: ./index.php?action=connexionForm');
        }

        $this->traiteVariablesPost();
    }

    /**
     * Allows to check differents variables which represents data user from the view
     *
     * @return Function 'soumissionPremiereCause' after verification of user's data entered
     */
    public function traiteVariablesPost()
    {
        $_SESSION['erreur_message'] = null;
        $tabErreur = array();

        $resultCheckRadio = checkRadio($_POST['radio-1']);
        $resultCheckDatetime = checkInput($_POST['datetimepicker'], '/^[0-9]{4}[-][0-1]{1}[0-9]{1}[-][0-3]{1}[0-9]{1}[ ][0-2]{1}[0-9]{1}[:][0-5]{1}[0-9]{1}$/', "Date");
        $resultCheckDescriptif = checkTextarea($_POST['motif'], 254, "Déscriptif");
        $resultCheckCommentaire = checkTextarea($_POST['commentaire'], 254, "Commentaire");

        if ($_POST['moule1'] > 0)
        { 
            $tabMoule[]=$_POST['moule1']; 
        }
        if ($_POST['moule2'] > 0)
        { 
            $tabMoule[]=$_POST['moule2']; 
        }
        if ($_POST['moule3'] > 0)
        { 
            $tabMoule[]=$_POST['moule3']; 
        }

        if(empty($tabMoule))
        {
            $ensembleMoule1 = null; 
        }
        else
        {
            foreach ($tabMoule as $value)
            { 
                $ensembleMoule1.= $value."-"; 
            }
            //Ex : $rest = substr("abcdef", 0, -1); -> Get "abcde"
            $ensembleMoule1 = substr($ensembleMoule1, 0,-1);
        }
    
        if ($_POST['sectionMouleNumero1'] != "?")
        { 
            $tabSectionCavite[]=($_POST['sectionMouleNumero1'].$_POST['sectionMouleValeur1']); 
        }
        if ($_POST['sectionMouleNumero2'] != "?")
        { 
            $tabSectionCavite[]=($_POST['sectionMouleNumero2'].$_POST['sectionMouleValeur2']); 
        }
        if ($_POST['sectionMouleNumero3'] != "?")
        { 
            $tabSectionCavite[]=($_POST['sectionMouleNumero3'].$_POST['sectionMouleValeur3']); 
        }

        if($tabSectionCavite=="???" || empty($ensembleMoule1))
        {
            $ensembleSectionCavite1 = null;
        }
        else
        {
            foreach ($tabSectionCavite as $value)
            { 
                $ensembleSectionCavite1.= $value."-";
            }

            $ensembleSectionCavite1 = substr($ensembleSectionCavite1, 0,-1);
        }

        array_push($tabErreur, $resultCheckRadio, $resultCheckDatetime, $resultCheckDescriptif, $resultCheckCommentaire);

        $_SESSION['erreur_message'] = $tabErreur;

        //If no production line were selected by user
        foreach ($_SESSION['erreur_message'] as $value)
        {
            if(!is_null($value) || $value =="Veuillez sélectionner une ligne")
            {
                header('Location: ./index.php?action=afficherBlocageSaisie');
                exit();
            }
        }

        $idCause = 1;
        $this->soumissionPremiereCause($ensembleMoule1,$ensembleSectionCavite1,$idCause);

        if($_POST['cause2'] != "?")
        {
            if ($_POST['moule4'] > 0) { $tabMoule2[]=$_POST['moule4']; }
            if ($_POST['moule5'] > 0) { $tabMoule2[]=$_POST['moule5']; }
            if ($_POST['moule6'] > 0) { $tabMoule2[]=$_POST['moule6']; }
        
            if(empty($tabMoule2))
            {
                $ensembleMoule2 = null;
            }
            else
            {
                foreach ($tabMoule2 as $value)
                {
                    $ensembleMoule2.= $value."-";
                }

                $ensembleMoule2 = substr($ensembleMoule2, 0,-1);
            }

            if ($_POST['sectionMouleValeur4'] != "?") { $tabSectionCavite2[]=($_POST['sectionMouleValeur4'].$_POST['sectionMouleValeur4']); }
            if ($_POST['sectionMouleValeur5'] != "?") { $tabSectionCavite2[]=($_POST['sectionMouleValeur5'].$_POST['sectionMouleValeur5']); }
            if ($_POST['sectionMouleValeur6'] != "?") { $tabSectionCavite2[]=($_POST['sectionMouleValeur6'].$_POST['sectionMouleValeur6']); }
        
            if($tabSectionCavite2=="???" || empty($ensembleMoule2))
            {
                $ensembleSectionCavite2 = null;
            }
            else
            {
                foreach ($tabSectionCavite2 as $value)
                {
                    $ensembleSectionCavite2.= $value."-";
                }

                $ensembleSectionCavite2 = substr($ensembleSectionCavite2, 0,-1);
            }

            $idCause = 2;
            $this->soumissionPremiereCause($ensembleMoule2,$ensembleSectionCavite2,$idCause);  
        }

        if($_POST['cause3'] != "?")
        {
            if ($_POST['moule7'] > 0) { $tabMoule3[]=$_POST['moule7']; }
            if ($_POST['moule8'] > 0) { $tabMoule3[]=$_POST['moule8']; }
            if ($_POST['moule9'] > 0) { $tabMoule3[]=$_POST['moule9']; }
        
            if(empty($tabMoule3))
            {
                $ensembleMoule3 = null;
            }
            else
            {
                foreach ($tabMoule3 as $value)
                {
                    $ensembleMoule3.= $value."-";
                }

                $ensembleMoule3 = substr($ensembleMoule3, 0,-1);
            }
            
            if ($_POST['sectionMouleValeur7'] != "?") { $tabSectionCavite3[]=($_POST['sectionMouleValeur7'].$_POST['sectionMouleValeur7']); }
            if ($_POST['sectionMouleValeur8'] != "?") { $tabSectionCavite3[]=($_POST['sectionMouleValeur8'].$_POST['sectionMouleValeur8']); }
            if ($_POST['sectionMouleValeur9'] != "?") { $tabSectionCavite3[]=($_POST['sectionMouleValeur9'].$_POST['sectionMouleValeur9']); }
        
            if($tabSectionCavite3=="???" || empty($ensembleMoule3))
            {
                $ensembleSectionCavite3 = null;
            }
            else
            {
                foreach ($tabSectionCavite3 as $value)
                {
                    $ensembleSectionCavite3.= $value."-";
                }

                $ensembleSectionCavite3 = substr($ensembleSectionCavite3, 0,-1);
            }

            $idCause = 3;
            soumissionPremiereCause($ensembleMoule3,$ensembleSectionCavite3,$idCause);  
        }

        $this->redirectionBlocageHistorique();
    }

    /**
     * Allows to insert differents variables which represents data user from the view
     * @param String $ensembleMoule all moule selected by user
     * @param String $ensembleSectionCavite all section/cavity selected by user
     * @param Number $idCause What cause was informed
     * @return Succes or Error of insert
     */
    public function soumissionPremiereCause($ensembleMoule,$ensembleSectionCavite,$idCause)
    {   
        $connexion = new Connexion; 
        $blocageMapper = new BlocageMapper($connexion);
        $blocage = new BlocageFinder($connexion);
        $utilisateurMapper = new UtilisateurMapper($connexion); 
        $utilisateurFinder = new UtilisateurFinder($connexion);

        $qtte = ($_POST['paletteFin'] == 0) ? '0' : ($_POST['paletteFin'] - $_POST['paletteDebut']+1);

        if($idCause == 1)
        {
            $motif = preg_replace("/\r\n/",' - ',$_POST['motif']);
            $commentaire = preg_replace("/\r\n/",' - ',$_POST['commentaire']);

            //Creation of object Blocage from file Blocage.php which represents entity Blocage
            $newBlocage = new Blocage($_POST['lot'], $_POST['paletteDebut'], $_POST['paletteFin'], $qtte, 
                                      $_POST['statut'], $_POST['datetimepicker'], $_POST['cause'], htmlspecialchars($motif, ENT_QUOTES), 
                                      htmlspecialchars($commentaire, ENT_QUOTES), $ensembleMoule, $ensembleSectionCavite, 
                                      $_POST['datetimepicker'], date("Y-m-d H:i:s"), null, null, 0, $_POST['radio-1'], $_SESSION['usr_id'], 
                                      $_SESSION['sap_id']);
            try 
            {
                //Persist object created
                $blocageMapper->persist($newBlocage); 
            }
            catch(Exception $e)
            {
                $_SESSION['erreur_message'] = "Erreur pendant l'insertion en base de données";
                header('Location: ./index.php?action=afficherBlocageSaisie'); 
                exit();
            }
            if($_POST['cause'] == "CRITIQUE(défaut verrier)" || $_POST['cause'] == "CRITIQUE(risque verre)" && $_SESSION['ajoutDefautCritique'] == 1)
            {
                $defautCritiqueMapper = new DefautCritiqueMapper($connexion);
                $defautcritique = new DefautCritiqueFinder($connexion);

                $dernierDefautCritique = $defautcritique->findLastDefId();
                $idDernierDefautCritique = $dernierDefautCritique[0]["MAX(`def_id`)"];
                
                $dernierBlocage = $blocage->findLastBlocageId();
                $idDernierBlocage = $dernierBlocage[0]["MAX(`bloc_id`)"];
                

                $defautCritiqueMapper->persistFkBlocId($idDernierDefautCritique, $idDernierBlocage);
                $_SESSION['ajoutDefautCritique'] == 0;

                //Insert value in file CSV
              /*try
                {
                    $retourFonction = new DefautCritiqueVersFichierMetrix;
                    $retourFonction->ecrireDansFichierCharge($_SESSION['ajoutDefautCritiqueAttributPoste'],$_SESSION['ajoutDefautCritiqueAttributEquipe']);
                    
                    unset($_SESSION['ajoutDefautCritiqueAttributPoste']);
                    unset($_SESSION['ajoutDefautCritiqueAttributEquipe']);
                } 
                catch (Exception $e1)
                {
                    echo 'Exception reçue : ',  $e1->getMessage(), "\n";
                    header('Location: ./ValidationDonnees/Erreur/ErreurEcritureDansFichierMetrix.html'); 
                    exit();
                }*/
            }
        }
        else if($idCause == 2)
        {
            $motif2 = preg_replace("/\r\n/",' - ',$_POST['motif2']);
            $commentaire2 = preg_replace("/\r\n/",' - ',$_POST['commentaire2']);

            //Creation of object Blocage from file Blocage.php which represents entity Blocage
            $newBlocage = new Blocage($_POST['lot'], $_POST['paletteDebut'], $_POST['paletteFin'], $qtte, 
                                      $_POST['statut'], $_POST['datetimepicker'], $_POST['cause2'], htmlspecialchars($_POST['motif2'], ENT_QUOTES), 
                                      htmlspecialchars($_POST['commentaire2'], ENT_QUOTES), $ensembleMoule, $ensembleSectionCavite, 
                                      $_POST['datetimepicker'], date("Y-m-d H:i:s"), null, null, 0, $_POST['radio-1'], 
                                      $resultatId[0]['usr_id'], $_SESSION['sap_id']);
            try
            {
                //Persist object created
                $blocageMapper->persist($newBlocage);
            }
            catch(Exception $e)
            {
                $_SESSION['erreur_message'] = "Erreur pendant l'insertion en base de données";
                header('Location: ../index.php?action=afficherBlocageSaisie');
                exit();
            }
        }
        else if($idCause == 3)
        {

            $motif3 = preg_replace("/\r\n/",' - ',$_POST['motif3']);
            $commentaire3 = preg_replace("/\r\n/",' - ',$_POST['commentaire3']);

            //Creation of object Blocage from file Blocage.php which represents entity Blocage
            $newBlocage = new Blocage($_POST['lot'], $_POST['paletteDebut'], $_POST['paletteFin'], $qtte, $_POST['statut'], 
                                      $_POST['datetimepicker'], $_POST['cause3'], htmlspecialchars($_POST['motif3'], ENT_QUOTES), 
                                      htmlspecialchars($_POST['commentaire3'], ENT_QUOTES), $ensembleMoule, $ensembleSectionCavite, 
                                      $_POST['datetimepicker'], date("Y-m-d H:i:s"), null, null, 0, $_POST['radio-1'], 
                                      $resultatId[0]['usr_id'], $_SESSION['sap_id']);
            try
            {
                //Persist object created
                $blocageMapper->persist($newBlocage);
            }
            catch (Exception $e) 
            {
                $_SESSION['erreur_message'] = "Erreur pendant l'insertion en base de données";
                header('Location: ./index.php?action=afficherBlocageSaisie');
                exit();
            }
        }   
    }
    
    /**
     * Allows to redirect user to historical historique of the application after insert a blocage.
     *
     * @return The home page
     */
    public function redirectionBlocageHistorique()
    {
        if (!headers_sent($filename, $linenum))
        {
            $confirmation="OK";
            header('Location: ./index.php?action=afficherBlocageHistorique&confirmation='.$confirmation);
            exit;
        } 
        else
        {
            echo "Les en-têtes ont déjà été envoyés, depuis le fichier $filename à la ligne $linenum\n" .
                 "Il est donc impossible de vous rediriger automatiquement, aussi veuillez
                 revenir en arrière. Votre enregistrement à quand-même été pris en compte.\n";
            exit;
        }

        $confirmation="OK";
        header('Location: ./index.php?action=afficherBlocageHistorique&confirmation='.$confirmation);
        ob_end_flush();
    }

    /**
     * Allows to update (edit) a specific blocage in historical dataTables
     * @return Success or Error of update
     */
    public function editBlocage()
    {
        $connexion = new Connexion;
        $blocageMapper = new BlocageMapper($connexion);
        $blocageFinder = new BlocageFinder($connexion);

        $tabErreur = array();
        $nbrErreurs =0;

        //Get the field of the table to update it
        $nameBD = $_GET['nameBD'];
        //Get the value that user wants to update
        $elementToUpdate = $_GET['elementToUpdate'];

        $infoPalette = $blocageFinder->findInfoPaletteById($_GET['idRecording']);

        //Condition to automatically calculate quantity after have filled "numero_debut" or "numero_fin"
        if($nameBD == "numero_debut")
        {
            $qtte = $infoPalette[0]['bloc_numero_fin'] - $_GET['elementToUpdate']+1;
        } 
        if($nameBD == "numero_fin")
        {
            $qtte = $_GET['elementToUpdate'] - $infoPalette[0]['bloc_numero_debut']+1;
        }

        try
        {
            //Condition to check if the value to update is not related to the quantity 
            if($nameBD != "numero_debut" && $nameBD != "numero_fin")
            {
                 $result = $blocageMapper->editBlocage($_GET['idRecording'], htmlspecialchars($elementToUpdate, ENT_QUOTES), $nameBD, date("Y-m-d H:i:s"));
            }
            //Is related to the quantity 
            else
            {
                $result = $blocageMapper->editBlocageWithQtte($_GET['idRecording'], $elementToUpdate, $nameBD, date("Y-m-d H:i:s"), $qtte);
            } 
        }
        catch (Exception $e)
        {
            $tabErreur[]="<font color='red' id='erreur'> La modification de cet blocage a échoué !</br>";
            $nbrErreurs++;
            require('./Views/templates/Erreur/erreur.php');
            exit();
        }
        exit();
    }

    /**
     * When a user wants to delete a recording in BDD's table Blocage.
     *
     * @return Success or Error of delete
     */
    public function deleteBlocage()
    {
        $connexion = new Connexion;
        $blocageMapper = new BlocageMapper($connexion);
        
        $tabErreur=array();

        try
        {
            $result = $blocageMapper->remove($_GET['idRecording']);
        }
        catch (Exception $e) 
        {
            $tabErreur[]="<font color='red' id='erreur'> La suppression de ce blocage ne s'est pas correctement déroulée !</br>";
            $nbrErreurs++;
            require('./Views/templates/Erreur/erreur.php');
            exit();
        }
        exit();
    }
}
?>

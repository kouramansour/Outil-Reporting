<?php

/**
 * This class GenerateurMdp allow to generate a new id (password) for a user
 * @since 26 août 2016
 * @package ControleurAdmin
 * @author Jordan PROTIN <Jordan.Protin@yahoo.com> & Steven MARTINS
 */
class GenerateurMdp
{
    /**
     * Allows to automatically generate 4 ramdom numbers to add these to the end of the password
     * @param Number $longeur length of desired result
     * @return Number four ramdom numbers
     */
    public function genererDernierChiffre ($longueur = 4)
    {
        $result = "";
        //Numbers possible to generate
        $caracterePossible = "0123456789"; 
      
        //Calcul lenght of the string
        $longueurMax = strlen($caracterePossible); 
        if($longueur > $longueurMax)
        {
            //It's necessary to get 4 numbers
            $longueur = $longueurMax;
        }  

        $i = 0;

        // Add a random char to $mdp when $longueur is OK
        while ($i < $longueur) 
        { 
        	$caractereAleatoire = substr($caracterePossible, mt_rand(0, $longueurMax-1), 1);     
        	
            // Verify if the char is already used in $mdp
        	if(!strstr($result, $caractereAleatoire)) 
            {
        		$result .= $caractereAleatoire;
        		$i++;
        	}
        }    
        return $result;
    }

    /**
     * Allows to do the concatenation of different elements in order to create the id (password)
     * @param Number $prenom first name of the user
     * @param Number $nom name of the user
     * @return String The password created
     */
    public function concatenerPrenomNomChiffre ($prenom, $nom)
    {
        //Demand to generate 4 random numbers by calling the function just above
        $quatreDernierChiffre = (new GenerateurMdp())->genererDernierChiffre(); 
        //Keep only the 2 first letter of first name
    	$prenom = substr($prenom, 0, 2); 

        //Ex: return joprotin1234
    	return $prenom.strtolower($nom).$quatreDernierChiffre;
    }
}
?>
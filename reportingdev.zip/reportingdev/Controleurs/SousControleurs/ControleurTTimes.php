<?php

session_cache_limiter('private_no_expire, must-revalidate');

/**
 * Controleur de gestion des TTimes à retrouver dans le module job change. 
 * Pour chaque changement (entrée de la table "ordonancement"), une entrée dans la table "ttimes correspond"
 */
class ControleurTTimes 
{

    /**
     * Constructeur
     *
     */
    public function __construct() 
    {
        $_SESSION['page'] = "job";
        $action = Nettoyage::ClearString($_GET['action']);


        if (!$_SESSION['usr_role'] == "Admin" || !$_SESSION['usr_role'] == "User") 
        { 
            header('Location:./'); 
        }
        

        $this->$action();
        exit();
    }

    /**
     * Affiche les temps relatifs au changement de fab séléctioné
     */
    public function afficherTTimes()
    {
        $connexion = new Connexion;
        $ordonnancement = new OrdonnancementFinder($connexion);
        $ttimes = new TTimesFinder($connexion);
        $sapFinder = new SapFinder($connexion);
        $ligneFinder = new LigneFinder($connexion);

        $tabErreur[]= "";
    
        
        if(isset($_GET['idChangement']))
        {
            $id_ordonnancement= $_GET['idChangement'];

            //Get all parameters of class's in relation to the fabrication change in order to display each parameters on the view
            $tabResultatOrdo=$ordonnancement->findOneById($id_ordonnancement);
            $sap = $sapFinder->findSapById($tabResultatOrdo->getSap())[0];
            $times = $ttimes->findOneByOrdoId($tabResultatOrdo->getId()); 
            $objectifsChaud = $ttimes->findTimesBySecteurAndCat("chaud",$tabResultatOrdo->getCategorieChaud()); 
            $objectifsFroid = $ttimes->findTimesBySecteurAndCat("froid",$tabResultatOrdo->getCategorieFroid());

            // Convertion du temps d'arche en timestamp
            $tempsArcheTimestamp = timeToTimestamp($tabResultatOrdo->getTempsArche());
    
            // Convertion de l'heure du début du chgt en timestamp
            $debutChgtTimestamp = timeToTimestamp($tabResultatOrdo->getHeureArret());

            foreach ($objectifsChaud as $key => $value) {
                $objectifsChaud[$key] = timeToTimestamp($value);

            }

            foreach ($objectifsFroid as $key => $value) {
                $objectifsFroid[$key] = timeToTimestamp($value);

            }

            $debutChgtFroidTimestamp = $debutChgtTimestamp + $tempsArcheTimestamp;

            $ligne = $ligneFinder->findLigneById($tabResultatOrdo->getLigne())[0]['lig_numero'];
       
            //Passing all variables to this view in order to display of all these in it
            require('./Views/templates/JobChange/TTimes.php');
        }
           
    }

    /**
     * Mettre à jour les temps relatifs au chgt selectionné
     */
    function updateTTimes(){

        $connexion = new Connexion;
        $ttimesMapper = new TTimesMapper($connexion);

        foreach ($_POST as $value) 
            $value = htmlspecialchars($value);


        $return = $ttimesMapper->updateTTimes($_POST['idTtimes'], $_POST['debutChgtReal'],$_POST['finChgtReal'],$_POST['demarrageFabReal'],$_POST['miseVerreReal'],$_POST['miseArcheTotaleReal'],$_POST['archeVideReal'],$_POST['tempsArcheReal'],$_POST['arriveeArcheReal'],$_POST['debutChgtFroidReal'],$_POST['finChgtBrin1Real'],$_POST['finChgtBrin2Real'],$_POST['finChgtBrin3Real'],$_POST['finChgtBrin4Real'],$_POST['palettisationReal'],$_POST['arriveeTaaReal'],$_POST['validationReal'],$_POST['1erePalBonneReal'],$_POST['fabBonneReal'],$_POST['machineQualReal'],$_POST['poidsReal'],$_POST['cadenceReal'],$_POST['dureeChgtReal'],$_POST['dureeChgtFroidReal']);

       
        if(is_array($return))
            header('Location: ./index.php?action=afficherTTimes&idChangement='.$_POST['idChangement']);
        else {
            require('./Views/templates/Erreur/erreur.php');
        }
    }

    /**
    * Calcul du delta entre deux temps et du %tage du temps de JC (12h)
    */
    public function ajaxGetTimeDeltaTTimes() {

        $tps1 = timeToTimestamp($_GET['tps1']);
        $tps2 = timeToTimestamp($_GET['tps2']);

        $delta = $tps1 - $tps2;

        echo 'Delta : ';

        if($delta > 0 )
            echo '<span style="color:green;font-weight:bold;">-'; 

        elseif($delta == 0 )
             echo '<span style="color:green;font-weight:bold;">';

        else
            echo '<span style="color:red;font-weight:bold;">+';

       
        echo gmdate('H:i', abs($delta)).'</span>';

        if($delta < 0)
            echo ' / '.number_format((abs($delta)*100/43200),2).'% du tps de JC';

    }

    
   
}
?>

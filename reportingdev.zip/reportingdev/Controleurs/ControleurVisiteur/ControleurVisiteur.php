<?php

session_cache_limiter('private_no_expire, must-revalidate');
require_once (__DIR__.'/../../ValidationDonnees/Validation.php');

/**
 * This class ControleurVisiteur allow to manage visitor's actions.
 * @since 26 août 2016
 * @package ControleurVisiteur
 * @author Jordan PROTIN <Jordan.Protin@yahoo.com>
 */
class ControleurVisiteur
{

    /**
     * Class's constructor.
     *
     * @return Function[name] Call the good function according action
     */
	function __construct() 
    {
        $_SESSION['page'] = "accueil";

        $tabErreur = array();

        try
        { 

            //Get user's action (the route)
            $action = $_GET['action'];
            
        	switch($action) 
        	{
                case NULL:
                    //Redirect to login page
                    $this->FormConnexion();
                    break;
                case "connexionForm" :
                    //Redirect to login page
                    $this->FormConnexion();
                    break;
                case "connexion" :
                    //Redirect to function connexion when user has entered his id
                    $this->connexion();
                    break;
                default: 
        			$tabErreur[] = "<font color='red'>Erreur d'appel php | Pensez à supprimer vos cookies navigateur</font>";
                    require('./Views/templates/Erreur/erreur.php');
                    break;
            }

        }
        catch (PDOException $ExceptionErreurPDO)
        {
            $tabErreur[] = "<font color='red'>Erreur intervenue sur la base de données | Veuillez contacter un administrateur</font>";
            require('./Views/templates/Erreur/erreur.php');
        }
        catch (Exception $ExceptionErreur) 
        {
            $tabErreur[] = "<font color='red'>Erreur inattendue sur le site | Veuillez contacter un administrateur</font>";
            require('./Views/templates/Erreur/erreur.php');
        }
        exit(0);

    }
	
    /**
     * Allows a user to display the login page of the application.
     *
     * @return The login page
     */
    public function FormConnexion()
    {

        require('./Views/Accueil.php');
    }
    
    /**
     * Function called when a user has entered his id in order to connect to the application.
     *
     * @return The good Controller[rôle] according the user's role (Visitor,User or Admin)
     */
    public function connexion()
    {

        if(!isset($_POST['visitorConnection'])){
            //Get the user's id to verify it
            $param=array($_POST['identifiant']); 

            if(validChamps($param))
            {
                //Get the user's id
                $identifiant=$_POST['identifiant'];

                $actor= new ModelActor();
                //Called the function connexion from file ModelActor to verify if this user's id is correct
                $tab = $actor->connexion($identifiant); 

                //If result of function connexion is NULL => display an error message
        		if($tab == NULL)
                {
                    echo "<font color='red' id='erreur'>Cet identifiant est inconnu, veuillez réessayer !</font></br>
                          <font color='black' id='secondErreur'>Identifiant oublié ? <a href='mailto:Jeremy.Metayer@eu.o-i.com'> Contactez l'administrateur </a></font>" ;
                    require("./Views/Accueil.php");

                }
                //Correct user's id in BDD
                else
                {
                    //Save all user's parameters in SESSION variable to use it in the future
                    $_SESSION['usr_id']=$tab[1]; 
                    $_SESSION['usr_role']=$tab[0]; 
                    
                    $_SESSION['usr_fonction1']= $tab[2];
                    $_SESSION['usr_prenom'] = $tab[3]; 
                    $_SESSION['usr_nom'] = $tab[4]; 
                    $_SESSION['usr_loginmdp']=$identifiant;

                    $connexion = new Connexion;
                    $droitsFinder = new DroitsUtilisateurFinder($connexion);

                    $droits = $droitsFinder->getRights($_SESSION['usr_fonction1']);
                    $_SESSION['rights'] = $droits;
                    
                    


                    //Call the good controller according the user's role during the connexion action
                    switch($tab[0])
                    {
                        case "User" : 
                            $_GET['action']=NULL;
                            new ControleurUser(); 
                            break;
                        case "Admin" :
                            $_GET['action']=NULL;
                            new ControleurAdmin();
                            break;
                        default :
                            $_GET['action']=NULL;
                            new ControleurVisiteur(); 
                            break;
                    } 
     
                
                }
            }
            //No user's id to find
            else
            {
                echo "<font color='red' id='erreur'>Il est nécessaire de renseigner un identifiant ! </font></br>";
                require("./Views/Accueil.php");
            }
        }
        else {

            $actor= new ModelActor();

            $_SESSION['usr_id']=0; 
            $_SESSION['usr_role']="User"; 
            
            $_SESSION['usr_fonction1']= 19;
            $_SESSION['usr_prenom'] = "Visiteur"; 
            $_SESSION['usr_nom'] = "VISITEUR"; 
            $_SESSION['usr_loginmdp']="";


            $connexion = new Connexion;
            $droitsFinder = new DroitsUtilisateurFinder($connexion);

            $droits = $droitsFinder->getRights($_SESSION['usr_fonction1']);
            $_SESSION['rights'] = $droits;

            $_GET['action']=NULL;
            new ControleurUser(); 
                    
        }
    }
}

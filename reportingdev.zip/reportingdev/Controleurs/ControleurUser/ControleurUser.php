<?php

session_cache_limiter('private_no_expire, must-revalidate');

/**
 * This class ControleurUser allow to manage user's actions.
 * @since 26 août 2016
 * @package ControleurUser
 * @author Jordan PROTIN <Jordan.Protin@yahoo.com>
 */
class ControleurUser
{

    /**
     * Class's constructor.
     *
     * @return Controleur[name] Call the good controller according action
     */
    function __construct()
    {
        $_SESSION['page'] = "accueil";
        $tabErreur=array();
        
        //Verify if user is really user
        if (!$_SESSION['usr_role'] == "User")
        { 
            header('Location:./'); 
        }

        try
        {
            //Route called from file FrontController.php
            $action = Nettoyage::ClearString($_GET['action']);

        
            // Array which contains differents controller's name
            $arrayModule= array('TTimes','PostJob','Ordonnancement','JobOff','PlanAction',
                                'PanneEvenement','DefautBlocage','Commun','Consigne', 'GestionUtilisateur', 'Sap');

            // Redirect user admin to the good sub controller according the route from file FrontController.php
            foreach ($arrayModule as $module)
            { 
                if($module != "Commun" && stripos($action, $module) !== false)
                {
                    $controleur="Controleur".$module; //Call the good controller here
                    new $controleur(); 
                }
                //An action that is not an integral part of a module is managed in this ControllerUser
                elseif($module == "Commun" && stripos($action, "Commun") !== false)
                {
                    $this->$action(); 
                    exit();
                }
            }     
   
            if($action == NULL)
            { 
                $this->afficherDashboardCommun(); 
                exit();
            }
        
            if($action == "")
            {
                $tabErreur[] = "<font color='red'>Erreur d'appel php | Pensez à supprimer vos cookies navigateur</font>";
                require('./Views/templates/Erreur/erreur.php');
                exit();
            }   
        }
        catch (PDOException $ExceptionErreurPDO)
        {
            $tabErreur[] = "<font color='red'>Erreur survenue sur la base de données | Veuillez contacter un administrateur</font>";
            require('./Views/templates/Erreur/erreur.php');
        }
        catch (Exception $ExceptionErreur)
        {
            $tabErreur[] = "<font color='red'>Erreur inattendue sur le site | Veuillez contacter un administrateur</font>";
            require('./Views/templates/Erreur/erreur.php');
        }
        exit(0);
    }    
    
    /**
     * Allows a user to disconnect from the application.
     *
     * @return The login page
     */
    public function deconnexionCommun()
    {
        $actor = new ModelActor();
        $actor->deconnexion();
        $_GET['action']=NULL;
        header('Location:./');
    }

   
    /**
     * Allows a user to display the home page of the application.
     *
     * @return The home page
     */
    public function afficherDashboardCommun() 
    {   
        try {
            $connexion = new Connexion; 
            $paletteFinder = new PaletteFinder($connexion);
            $palBloquees = $paletteFinder->countAllPalBloquees()['nbPal'];
        }
        catch (Exception $e) 
        {
            $palBloquees = $e->getMessage();   
        }

        

        require('./Views/templates/Home/Home.php');
    }

    /**
     * Allows to display the current production of a production line.
     *
     * @return sap's num, sap's code form and sap's name
     */
    public function ajaxProductionEnCoursCommun()
    {
        $connexion = new Connexion;
        $sapFinder = new SapFinder($connexion);

        //Search in BDD all sap paramaters according the line selected
        $sapEnCours = $sapFinder->findSapByNumeroLigne($_GET['ligne']); 

        $_SESSION['lig_num'] = $_GET['ligne']; 
        $_SESSION['sap_id'] = $sapEnCours[0]['sap_id']; 
        $_SESSION['sap_numero'] = $sapEnCours[0]['sap_numero']; 
        $_SESSION['sap_code_forme'] = $sapEnCours[0]['cf_numero']; 
        $_SESSION['sap_libelle'] = $sapEnCours[0]['sap_libelle']; 
       
  

        $retour = "<font color=#D30046;><strong>SAP</strong></font> : ".$sapEnCours[0]['sap_numero']." - <font color=#D30046;><strong>CF. </strong></font> : ".$sapEnCours[0]['cf_numero']." / ".$sapEnCours[0]['sap_libelle'];

        $retour .='
        <input style="text" name="ligne" id="ligne" value="'.$_GET['ligne'].'" hidden="true" />
        <input style="text" name="lig_id" id="lig_id" value="'.$sapEnCours[0]['lig_id'].'" hidden="true" />
        <input style="text" name="sap_num" id="sap_num" value="'.$sapEnCours[0]['sap_numero'].'" hidden="true" />
        <input style="text" name="sap_id" id="sap_id" value="'.$sapEnCours[0]['sap_id'].'" hidden="true" />
        <input style="text" name="sap_code_forme" id="sap_code_forme" value="'. $sapEnCours[0]['cf_numero'].'" hidden="true" />
        <input style="text" name="sap_libelle" id="sap_libelle" value="'.$sapEnCours[0]['sap_libelle'].'" hidden="true" />';

        echo $retour;

    }

    /**
     * Allows to display the previous production of a production line.
     *
     * @return sap's id, sap's code 
     */
    public function ajaxPrevSapCommun()
    {
       
        try {

            $connexion = new Connexion; 
            $sapFinder = new SapFinder($connexion);
            $sap = $sapFinder->findPrevSap($_GET['ligne']);
            echo json_encode($sap);
            return json_encode($sap);
        }
        catch (Exception $e) 
        {
            return $e->getMessage();   
        }


    }
    
    

    /**
     * Allows to display the all user in dropdown list during a post opinion.
     *
     * @return id, name and surname of all user.
     */
    public function searchUserCommun()
    {
        $connexion = new Connexion;
        $utilisateurFinder = new UtilisateurFinder($connexion);

        if($_GET['listeUtilisateur'] == 0)
        {
            $listeUtilisateur = $utilisateurFinder->findAllUser();

            for($i=0; $i<count($listeUtilisateur); $i++ )
            {
                echo ($listeUtilisateur[$i]['usr_id']."$".$listeUtilisateur[$i]['usr_nom']."$".
                      $listeUtilisateur[$i]['usr_prenom']."$");    
            }
            exit();
        }
    }

   

    /**
     * Allow to search all user in BDD.
     *
     * @return The user's id, user's name and user's surname.
     */
    public function searchAllUsersCommun()
    {
        $connexion = new Connexion; 
        $utilisateurFinder = new UtilisateurFinder($connexion); 

        if($_GET['listeUsers'] == 0)
        {
            $listeUsers = $utilisateurFinder->findAllUsersForPanne();

            for($i=0; $i<count($listeUsers); $i++ )
            {
                echo ($listeUsers[$i]['usr_id']."$".$listeUsers[$i]['usr_nom']."$".$listeUsers[$i]['usr_prenom']."$");  
            }
            exit();
        }
    }

     /**
     * Récupère tous les blocages liés à un défaut
     *
     * @return les blocages
     */
    public function searchDefBlocagesCommun()
    {
        $connexion = new Connexion; 
        $finder = new BlocageFinder($connexion); 

            $blocages = $finder->findDefautBlocages($_GET['defautId']);
       
            for($i=0; $i<count($blocages); $i++ )
            {
                $date = date('d-m-Y H:i', strtotime($blocages[$i]['bloc_date']));
              
                echo ('<option value="'.$blocages[$i]['bloc_id'].'">Blocage n°'.$blocages[$i]['bloc_id'].' du '.$date.'</option>');  
            }
            exit();
    }
    

     /**
     * Allow to search all lines in BDD.
     *
     * @return The line's id, line's nulber 
     */
    public function searchAllLinesCommun()
    {
        $connexion = new Connexion; 
        $ligneFinder = new LigneFinder($connexion); 

       
        $lignes = $ligneFinder->getLignes();

        for($i=0; $i<count($lignes); $i++ )
        {
            echo '<option value="'.$lignes[$i]['lig_id'].'">'.$lignes[$i]['lig_numero'].'</option>'; 
        }
        exit();
   
    }

     /**
     * Allow to search all palets in BDD.
     *
     * @return The palet's id, palet's number and palet's state.
     */
    public function searchAllPaletsCommun()
    {
        $connexion = new Connexion; 
        $paletteFinder = new PaletteFinder($connexion); 

       if($_GET['idBloc']) {
            
            $palets = $paletteFinder->findPaletsByBloc($_GET['idBloc']);
         
            echo json_encode($palets);
            
        }
        exit();
   
    }
}

<?php

session_cache_limiter('private_no_expire, must-revalidate');


class ControleurSap 
{

    /** 
     * Class's constructor.
     *
     * @return Function[name] Call the good function according action
     */
    public function __construct()
    {
        $_SESSION['page'] = "sap";

        $action = Nettoyage::ClearString($_GET['action']);

        //Check if the user has the necessary rights for this module
        if (!$_SESSION['usr_role'] == "Admin" || !$_SESSION['usr_role'] == "User") 
        { 
            header('Location:./'); 
        }
        
        //By default, first $action called is 'afficherSap'
        $this->$action(); 
    }

    /**
     * Allows a user to display the sap page of the application.
     *
     * @return The sap page
     */
    public function afficherSap()
    {
        require ('./Views/templates/Sap/Sap.php');

        unset($_SESSION['message']);
    }


    // Used by autocomplete 
    public function rechercheSap()
    {
        $connexion = new Connexion; 
        $sapFinder = new SapFinder($connexion); 

        if(isset($_GET['query']))
        {
            //Word entered by user on the input   
            $q = htmlentities($_GET['query']);  
            $listeSap= $sapFinder->findAllSap($q);

            for($i=0; $i<count($listeSap); $i++ )
            {
                //Display suggestions list
                $suggestions['suggestions'][$i]['id'] = $listeSap[$i]['sap_id']; 
                $suggestions['suggestions'][$i]['value'] = $listeSap[$i]['sap_numero']; 
                $suggestions['suggestions'][$i]['cf'] = $listeSap[$i]['cf_numero'];
                $suggestions['suggestions'][$i]['libelle'] = $listeSap[$i]['sap_libelle'];
            }
            echo json_encode($suggestions); 
  
        }  
    }

    /**
     * When a user wants to delete a recording in BDD's table Sap.
     *
     * @return Success or Error of delete
     */
    public function RemoveSap()
    {
        $connexion = new Connexion; 
        $sapMapper = new SapMapper($connexion); 

        try
        {
            $result = $sapMapper->remove($_GET['idSap']);

            if($result === false)
                throw new Exception("Impossible de supprimer le code SAP !", 1);

            $_SESSION['message'] = "Suppression effectuée !";

            $this->afficherSap();

        }
        catch (Exception $e)
        {
            $_SESSION['message'] = $e->getMessage();

            $this->afficherSap();
        }
      
    }

    /**
     * When a user wants to delete a recording in BDD's table Sap.
     *
     * @return Success or Error of delete
     */
    public function RemoveCfSap()
    {
        $connexion = new Connexion; 
        $sapFinder = new SapFinder($connexion); 
        $cfMapper = new CodeFormeMapper($connexion); 

        try
        {   
            $sap = $sapFinder->findSapBy(array("sap_fk_codeforme_id"=>$_GET['idCf']));
            if($sap)
                throw new Exception("Impossible de supprimer le code forme, un code SAP y est associé.", 1);

            $result = $cfMapper->remove($_GET['idCf']);

            if($result === false)
                throw new Exception("Impossible de supprimer le code forme !", 1);

            $_SESSION['message'] = "Suppression effectuée !";

            $this->afficherSap();

        }
        catch (Exception $e)
        {
            $_SESSION['message'] = $e->getMessage();

            $this->afficherSap();
        }
      
    }

    /**
     * When a user wants to insert a recording in BDD's table Sap.
     *
     */
    public function addSap()
    {
        if(!isset($_SESSION['usr_loginmdp']))
            header ('location: ./index.php?action=connexionForm');
        
       
        $connexion = new Connexion;
        $sapMapper = new SapMapper($connexion); 
        $sapFinder = new SapFinder($connexion);
        
        $exists = $sapFinder->findSapBy(array('sap_numero' => $_POST['sapNumero'], 'sap_fk_lig_id' => $_POST['idLig']));

        try
        {

            if(!empty($exists))
                throw new Exception("Un SAP ayant ce numéro existe déjà pour cette ligne !");
            

            //Creation of object SAP from file Sap.php which represents entity Sap
            $newSap = new Sap($_POST['sapNumero'], $_POST['cfId'], htmlspecialchars($_POST['sapLibelle'],ENT_QUOTES), date("Y-m-d H:i"), $_POST['idLig'], null);  
            
            //Persist object created
            $result = $sapMapper->persist($newSap); 

            if($result === false)
                throw new Exception("Impossible d'enregistrer le code SAP !", 1);

            $_SESSION['message'] = "Code SAP ".$_POST['sapNumero']." bien enregistré !";

            $this->afficherSap();

        } 
        catch(Exception $e)
        {
            
            $_SESSION['message'] = $e->getMessage();

            $this->afficherSap();
        }
    }

    /**
     * When a user wants to insert a recording in BDD's table Sap.
     *
     */
    public function addCfSap()
    {
        if(!isset($_SESSION['usr_loginmdp']))
            header ('location: ./index.php?action=connexionForm');
        
       
        $connexion = new Connexion;
        $cfMapper = new CodeFormeMapper($connexion); 
        $cfFinder = new CodeFormeFinder($connexion);
        
        $exists = $cfFinder->findCodeFormeBy(array('cf_numero' => $_POST['CodeForme'], 'cf_fk_lig_id' => $_POST['idLig']));

        try
        {

            if(!empty($exists))
                throw new Exception("Un Code forme ayant ce numéro existe déjà pour cette ligne !");
            

            //Creation of object SAP from file Sap.php which represents entity Sap
            $newCf = new CodeForme(null, $_POST['CodeForme'], htmlspecialchars($_POST['cfLibelle'],ENT_QUOTES), date("Y-m-d H:i"), null, $_POST['idLig'], $_POST['type']);  

            //Persist object created
            $result = $cfMapper->persist($newCf); 

            if($result === false)
                throw new Exception("Impossible d'enregistrer le code forme !", 1);

            $_SESSION['message'] = "Code forme ".$_POST['CodeForme']." bien enregistré !";

            $this->afficherSap();

        } 
        catch(Exception $e)
        {
            
            $_SESSION['message'] = $e->getMessage();

            $this->afficherSap();
        }
    }
  


    /**
     * Display result suggestions by a system of autocomplete to display sap's number
     *
     * @return List of suggestions of sap's number
     */
    public function ajaxFindAllSap()
    {
        $connexion = new Connexion; 
        $sapFinder = new SapFinder($connexion); 

        $codes = $sapFinder->findSapBy(array('sap_fk_lig_id'=>$_GET['idLig']));

        //Display result in JSON format to treat it in file javascript
        echo json_encode($codes);
    }

    public function ajaxGetSap()
    {
        $connexion = new Connexion; 
        $sapFinder = new SapFinder($connexion); 

        $sap = $sapFinder->findSapById($_GET['sapId'])[0];

        //Display result in JSON format to treat it in file javascript
        echo json_encode($sap);
    }

    /**
     * Récupère les codes forme par ligne 
     */
    public function AjaxFindAllCfSap()
    {   

        $connexion = new Connexion;
        $cfFinder = new CodeFormeFinder($connexion);

        $codes = $cfFinder->findCodeFormeBy(array('cf_fk_lig_id'=>$_GET['idLig']));

        //Display result in JSON format to treat it in file javascript
        echo json_encode($codes);

    }

    /**
     * Allows to update (edit) a specific sap in historical dataTables
     * @return Success or Error of update
     */
    public function editSap()
    {
        $connexion = new Connexion;
        $sapMapper = new SapMapper($connexion);

        //Get the field of the table to update it
        $nameBD = $_GET['nameBD'];
        //Get the value that user wants to update
        $elementToUpdate = $_GET['elementToUpdate'];

        try
        {
            $result = $sapMapper->editSap($_GET['idRecording'], htmlspecialchars($elementToUpdate, ENT_QUOTES), $nameBD);
            
            if($result === false)
                throw new Exception("Impossible de modifier le code SAP !");

            $_SESSION['message'] = "Code SAP modifié !";

            $this->afficherSap();

        }
        catch(Exception $e)
        {
            $_SESSION['message'] = $e->getMessage();

            $this->afficherSap();
        }
 
    }

    /**
     * Allows to update (edit) a specific sap in historical dataTables
     * @return Success or Error of update
     */
    public function editCfSap()
    {
        $connexion = new Connexion;
        $cfMapper = new CodeFormeMapper($connexion);

        //Get the field of the table to update it
        $nameBD = $_GET['nameBD'];
        //Get the value that user wants to update
        $elementToUpdate = $_GET['elementToUpdate'];

        try
        {
            $result = $cfMapper->editCf($_GET['idRecording'], htmlspecialchars($elementToUpdate, ENT_QUOTES), $nameBD);
            
            if($result === false)
                throw new Exception("Impossible de modifier le code forme !");

            $_SESSION['message'] = "Code forme modifié !";

            $this->afficherSap();

        }
        catch(Exception $e)
        {
            $_SESSION['message'] = $e->getMessage();

            $this->afficherSap();
        }
 
    }
}
?>

<?php

session_cache_limiter('private_no_expire, must-revalidate');

/**
 * This class ControleurAffectation allows to manage all module affectation's actions.
 * @since 26 août 2016
 * @package SousControleurs
 * @author Jordan PROTIN <Jordan.Protin@yahoo.com> & Steven MARTINS
 */
class ControleurAffectation 
{

    /** 
     * Class's constructor.
     *
     * @return Function[name] Call the good function according action
     */
    public function __construct()
    {
        $_SESSION['page'] = "sap";
    	$tabErreur = array();
        $action = Nettoyage::ClearString($_GET['action']);

        //Check if the user has the necessary rights for this module
        if (!$_SESSION['usr_role'] == "Admin" || !$_SESSION['usr_role'] == "User") 
        { 
            header('Location:./'); 
        }
        
        //By default, first $action called is 'afficherAffectation'
        $this->$action(); 
        exit();
    }

    /**
     * Allows a user to display the affectation(sap) page of the application.
     *
     * @return The sap(affectation) page
     */
    public function afficherAffectation()
    {
        require ('./Views/templates/Sap/Sap.php');
    }

    /**
     * When a user wants to delete a recording in BDD's table Sap.
     *
     * @return Success or Error of delete
     */
    public function SuppressionAffectation()
    {
        $connexion = new Connexion; 
        $sapMapper = new SapMapper($connexion); 

        try
        {
            $result = $sapMapper->remove($_GET['idSap']);
        }
        catch (Exception $e)
        {
            echo "Erreur : la suppression de cet article SAP n'a pas pu être réalisée...";
        }
        exit(); 
    }

    /**
     * When a user wants to insert a recording in BDD's table Sap.
     *
     * @return Function 'traiterVariablePost' after verification of user's identity
     */
    public function updateAffectation()
    {
        if(isset($_SESSION['usr_loginmdp']))
        {
            //Action nothing if unknown user
        }
        else
        {
            header ('location: ./index.php?action=connexionForm');
        }

        $this->traiterVariablePost();
    }

    /**
     * Allows to check differents variables which represents data user from the view
     *
     * @return Function 'gestionAffectation' after verification of user's data entered
     */
    public function traiterVariablePost()
    {
        $_SESSION['erreur_message'] = null;
        $tabErreur = array();
        $processMachine = null;

        $resultCheckNumSap = checkInput($_POST['sapNumero'], '/^[0-9]{6}$/', "N° du SAP");
        if(strlen($_POST['sapCodeForme']) > 4){
            $resultCheckCodeForme = checkInput($_POST['sapCodeForme'], '/^[0-9]/', "Code Forme");
        }else if(strlen($_POST['sapCodeForme']) < 5){
            $resultCheckCodeForme = "<div class='well'><font color='black'><i class='fa fa-arrow-right'></i> Code Forme : Vous devez renseigner au moins 5 chiffres !</font></div>";
        }

        $resultCheckLibelle = checkTextarea($_POST['sapLibelle'], 99, "Libellé du SAP"); //Max. 99 char
        $resultCheckBague = checkInput($_POST['bague'], '/^[0-9]{4}$/', "Bague");

        array_push($tabErreur, $resultCheckNumSap, $resultCheckCodeForme, $resultCheckLibelle, $resultCheckBague);

       
        foreach ($_SESSION['erreur_message'] as $value)
        {
            if(!is_null($value)){
                header('Location: ./index.php?action=afficherAffectation');
                exit();
            }
        }   

        //Check user's choice for process machine
        if($_POST['processMachine'] == "Autre")
        {
            $processMachine = $_POST['processMachineAutre']; 
        }else
        {
            $processMachine = $_POST['processMachine']; 
        }

        $this->gestionAffectation($processMachine);
    }

    /**
     * Allows to insert differents user data 
     * @param String $processMachine process machine selected by user
     * @return Success or Error of insert
     */
    public function gestionAffectation($processMachine)
    {   
        $connexion = new Connexion;
        $sapMapper = new SapMapper($connexion); 
        $sapFinder = new SapFinder($connexion);
        
        $checkTriplonExiste = $sapFinder->findTriplonSAPProcessMachineLigne($_POST['sapNumero'],$_POST['processMachine']);

        if(!empty($checkTriplonExiste))
        {
            $_SESSION['erreur_message'] = "Un SAP ayant ce numéro et ce process machine existe déjà !";
            header('Location: ./index.php?action=afficherAffectation');
            exit();
        }

        //Creation of object SAP from file Sap.php which represents entity Sap
        $newSap = new Sap($_POST['sapNumero'], $_POST['sapCodeForme'], htmlspecialchars($_POST['sapLibelle'],ENT_QUOTES), 
                          $_POST['bague'], $_POST['process'], $processMachine, $_POST['marche'], $_POST['sapTranche'], date("Y-m-d H:i"), null, null, 0);  
        try
        {
            //Persist object created
            $sapMapper->persist($newSap); 
        } 
        catch(Exception $e)
        {
            $_SESSION['erreur_message'] = "Erreur pendant l'insertion en base de données";
            header('Location: ./index.php?action=afficherAffectation');
            exit();
        }

    
        
        if (!headers_sent($filename, $linenum))
        {
            $confirmation="OK";
            header('Location: ./index.php?action=afficherAffectation&confirmation='.$confirmation);
            exit;
        }
        else
        {
            echo "Les en-têtes ont déjà été envoyés, depuis le fichier $filename à la ligne $linenum\n" .
            "Il est donc impossible de vous rediriger automatiquement, aussi veuillez
            revenir en arrière. Votre enregistrement à quand-même été pris en compte.\n";
            
            exit;
        }

        //Redirect to sap page after operation
        $confirmation="OK";
        header('Location: ./index.php?action=afficherAffectation&confirmation='.$confirmation);
        ob_end_flush();
    }

    /**
     * Allows to affect (current production sap) a specific sap
     * Function called from the scheduling ordonnancement [jobChange module]
     * @return Success or Error of insert
     */
    public function ajaxAffectation()
    {

            
        $connexion = new Connexion; 
        $sapMapper = new SapMapper($connexion); 
        $sapFinder = new SapFinder($connexion);
        $ligneFinder = new LigneFinder($connexion);
        $ordoMapper = new OrdonnancementMapper($connexion);

        //To display all process machine in dropDown list
        if(isset($_GET['comboProcessMachine']))
        {

            $listeProcessMachine = $sapFinder->findAllSapProcessMachine();

            for($i=0; $i<count($listeProcessMachine); $i++)
            {
                $indexId = $listeProcessMachine[$i]['sap_process_machine'];
                $value = $listeProcessMachine[$i]['sap_process_machine'];
                $json[$indexId][] = utf8_encode($value);
            }

            echo json_encode($json);
            exit();
        }

        //To display all process fabrication in dropDown list
        if(isset($_GET['comboProcessFab']))
        {
            $listeProcessFab = $sapFinder->findAllSapProcessFab();

            for($i=0; $i<count($listeProcessFab); $i++)
            {
                $indexId = $listeProcessFab[$i]['sap_process'];
                $value = $listeProcessFab[$i]['sap_process'];
                $json[$indexId][] = utf8_encode($value);
            }

            echo json_encode($json);
            exit();
        }


        //Proceed to the sap's affectation when user wants to affect it (current production sap in a specific production line)
        if ($_GET['affectation'] == 1)
        { 
            try
            {
                $sapId = $sapFinder->findIdSapByCodeSap($_GET['numeroSap'], 0);
                $ligId = $ligneFinder->findLigneByNum($_GET['ligne']);


                // Affect the sap to the prod line by setting lap_fk_sap_id in ligsap table
                $sapMapper->updateCoupleSapLigneDansLigsap($sapId[0]['sap_id'], $ligId[0]['lig_id']);

                // Set sap_affectation value to 1
                $result = $sapMapper->persistSapModify($_GET['numeroSap'], date("Y-m-d H:i:s"));
                

                // set ordo_mis_en_prod value to 1
                if(isset($_GET['ordoId']) && $_GET['ordoId']!= "")
                    $ordoMapper->mettreEnProd($_GET['ordoId']);


      

                echo "Succès : L'affectation de cet article SAP s'est correctement déroulée !";
            }
            catch (Exception $e)
            {
                echo "Erreur : L'affectation de cet article SAP a échoué !";
            }
            exit();     
        }
        else if ($_GET['affectation'] == 0)
        {
            $checkTriplonExiste = $sapFinder->findTriplonSAPProcessMachineLigne($_GET['sapNumero'], $_GET['processMachine'], $_GET['ligne']);
        
            if(!empty($checkTriplonExiste))
            {
                echo("Id de l'enregistrement : ".$checkTriplonExiste[0]['lap_id']);
                exit();
            }
            else
            {
                echo "Erreur : Aucun id d'enregistrement ne peut être fourni !"; 
            } 
        }
    }

    /**
     * Allows to update (edit) a specific sap in historical dataTables
     * @return Success or Error of update
     */
    public function editSapAffectation()
    {
        $connexion = new Connexion;
        $sapMapper = new SapMapper($connexion);

        $tabErreur = array();
        $nbrErreurs =0;

        //Get the field of the table to update it
        $nameBD = $_GET['nameBD'];
        //Get the value that user wants to update
        $elementToUpdate = $_GET['elementToUpdate'];

        try
        {
            $result = $sapMapper->editSapAffecte($_GET['idRecording'], htmlspecialchars($elementToUpdate, ENT_QUOTES), $nameBD);
        }
        catch(Exception $e)
        {
            $tabErreur[]="<font color='red' id='erreur'> La modification de cet article SAP a échoué !</br>";
            $nbrErreurs++;
            require('./Views/templates/Erreur/erreur.php');
            exit();
        }
        exit();
    }
}
?>

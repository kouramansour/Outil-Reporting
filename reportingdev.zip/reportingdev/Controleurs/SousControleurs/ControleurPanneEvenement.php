<?php

session_cache_limiter('private_no_expire, must-revalidate');

/**
* Controleur de gestion des pannes/evènements
*/
class ControleurPanneEvenement 
{

    private $connexion;
    /**
     * Constructeur 
     */
    public function __construct()
    {
        $this->connexion = new Connexion;
       
        $_SESSION['page'] = "pannes";
        $tabErreur = array();
        $action = Nettoyage::ClearString($_GET['action']);

        if (!$_SESSION['usr_role'] == "Admin" || !$_SESSION['usr_role'] == "User") 
        { 
            header('Location:./'); 
        }

        
        $this->$action(); 

        
        exit();   
    }

    /**
     * Affiche la liste des pannes/evenements 
     */
    public function afficherPanneEvenementHistorique()
    {   
     
      
        require('./Views/templates/PanneEvenement/PanneEvenementHistorique.php');
        
        unset($_SESSION['message']);
    }

    /**
     * Affiche la fenetre de saisie d'une nouvelle panne
     */
    public function afficherPanneEvenementSaisie()
    {
        $fmus = $this->RechercheUtilisateurFMUPanneEvenement();

        require('./Views/templates/PanneEvenement/PanneEvenementSaisie.php');

        unset($_SESSION['message']);
    }

    /**
     * Affiche le rapport des taux de pannes par service
     */
    public function afficherPanneEvenementRapport() {

        $lignesFinder = new LigneFinder($this->connexion);
        $lignes = $lignesFinder->getLignes();

        require('./Views/templates/PanneEvenement/PanneEvenementRapport.php');

        unset($_SESSION['message']);
    }

    /**
     * Récupère les niveaux de localisation de la panne
     */
    public function AjaxNiveauxPanneEvenement()
    {   

        $niveauxFinder = new NiveauxFinder($this->connexion);

        $json = array();

        //Search levels 0 in dataBase
        if(isset($_GET['go']))
        {
            $listeNiveau0 = $niveauxFinder->findAllCategories();

            for($i=0; $i<count($listeNiveau0); $i++)
            {
                $value = $listeNiveau0[$i]['niveauxpannes_categorie'];
                $json['categorie'][$i] = $value;
            }
        }
        //Search levels 1 in dataBase
        elseif (isset($_GET['categorie']) && !isset($_GET['sscategorie']))
        {
            $listeNiveau1 = $niveauxFinder->findAllSscatByCat($_GET['categorie']);

            for($i=0; $i<count($listeNiveau1); $i++)
            {
                $value = $listeNiveau1[$i]['niveauxpannes_sscategorie'];
                $json['sscategorie'][$i] = $value;
            }
        }
        //Search levels 2 in dataBase
        elseif (isset($_GET['sscategorie']) && isset($_GET['categorie']))
        {
            $listeNiveau2 = $niveauxFinder->findAllNiveauBySscat($_GET['categorie'], $_GET['sscategorie']);

            for($i=0; $i<count($listeNiveau2); $i++)
            {
                $value = $listeNiveau2[$i]['niveauxpannes_niveau'];
                $json['niveau'][$i] = $value;
            }
        }

       
        //Display result in JSON format to treat it in file javascript
        echo json_encode($json);

    }

    /**
     * Récupère l'ID d'un niveau de localisation de la panne
     */
    public function AjaxIdNiveauPanneEvenement() {   

        try{
            $niveauxFinder = new NiveauxFinder($this->connexion);

            $json = array();

           
            $niv = $niveauxFinder->findNiveauBy(array("niveauxpannes_categorie"=>$_GET['categorie'], "niveauxpannes_sscategorie"=>$_GET['sscategorie'], "niveauxpannes_niveau"=>$_GET['niveau']));

            if($ni === false)
                throw new Exception("Impossible de retrouver le niveau", 1);

            $json['id'] = $niv[0]['niveauxpannes_id'];


            //Display result in JSON format to treat it in file javascript
            echo json_encode($json);

        }
        catch(Exception $e)
        {
            
            $_SESSION['message'] = $e->getMessage();

            $this->afficherPanneEvenementHistorique();
        }


    }

   

    /**
     * Met à jour une panne (via le tableau historique)
     */
    public function updatePanneEvenement()
    {
   
        if (!isset($_SESSION['usr_loginmdp'])) {
        
            header ('location: ./index.php?action=connexionForm');
        }

        try{
            $panneEvenementMapper = new PanneEvenementMapper($this->connexion); 
            $niveauxFinder = new NiveauxFinder($this->connexion);
            $utilisateurFinder = new UtilisateurFinder($this->connexion); 
            $utilisateurMapper = new UtilisateurMapper($this->connexion);
            $ordoFinder = new OrdonnancementFinder($this->connexion);

            $ligneId = $_POST['lig_id'];

            $niveau = $niveauxFinder->findNiveauBy(array('niveauxpannes_categorie' => $_POST['niveau0'], 'niveauxpannes_sscategorie' => $_POST['niveau1'], 'niveauxpannes_niveau' => $_POST['niveau2']))[0];

            if($niveau === false)
                throw new Exception("Impossible de retrouver le niveau", 1);

            if($_POST['nbreSectionsMoules'] != "") {
                $seccav = "Nbre sections : ".$_POST['nbreSectionsMoules'];
                $nbreSections = $_POST['nbreSectionsMoules'];
            } 
            else { 

                $nbSections = round($_POST['nbSections']/2, 0, PHP_ROUND_HALF_UP);

                if($nbSections == 0)
                    $seccav = "NULL";
                else if( $ligneId == 1 | $ligneId == 2 && $nbSections == 10)
                    $seccav = "Toutes";
                else if($nbSections == 16 && $ligneId == 3)
                    $seccav = "Toutes";
                else if(isset($_POST['checkbox53A']) && $_POST['nbSections'] == 16 && $ligneId == 3)
                    $seccav = "Mach. 53A";
                else if(isset($_POST['checkbox53B']) && $_POST['nbSections'] == 16 && $ligneId == 3)
                    $seccav = "Mach. 53B";
                else if($ligneId == 4 | $ligneId == 5 | $ligneId == 6 | $ligneId == 7 && $nbSections == 12)
                    $seccav = "Toutes";
                else if(isset($_POST['checkbox55']) && $_POST['nbSections'] == 12 && $ligneId == 5)
                    $seccav = "Mach. 55";
                else if(isset($_POST['checkbox56']) && $_POST['nbSections'] == 12 && $ligneId == 5)
                    $seccav = "Mach. 56";
                else {
                    $seccav = "";
            
                    foreach ($_POST as $key => $value ) {

                        if(substr($key, 0, 7) == "seccav_")
                            $seccav .= "$".substr($key, 7)." ";
                    }
                    $seccav = substr($seccav, 0, -1);
                }
                $nbreSections = $nbSections;
           }
            
            
            $description = preg_replace("/\r\n/",' - ',$_POST['descriptif']);
            $cause = preg_replace("/\r\n/",' - ',$_POST['cause']);
            $actionrealisee = preg_replace("/\r\n/",' - ',$_POST['actionrealisee']);


            $ordo = $ordoFinder->findLastChangementByLine($ligneId);
            $tranche = $ordo[0]['ordo_date'];
          
            $loc = $niveau['niveauxpannes_categorie'];
            if(!empty($niveau['niveauxpannes_sscategorie']))
                $loc .= ' - '.$niveau['niveauxpannes_sscategorie'];
            if(!empty($niveau['niveauxpannes_niveau']))
                $loc .= ' - '.$niveau['niveauxpannes_niveau'];
        
            if(!$tranche)
                $tranche = "0";
            
            if($_POST['niveau0'] == 'Chaud') {
                $arret = $_POST['arretChaud'];
                $casse = $_POST['casseChaud'];
            }
            else {
                $arret = $_POST['arret'];
                $casse = $_POST['casse'];
            }
            //Creation of object PanneEvenement from file PanneEvenement.php which represents entity PanneEvenement
            $newPanneEvenement = new PanneEvenement($_POST['intervention'], $arret, $casse, htmlspecialchars($description, ENT_QUOTES), htmlspecialchars($cause, ENT_QUOTES), htmlspecialchars($actionrealisee, ENT_QUOTES), 
                $_POST['checkboxtermine'], $seccav, $_POST['datetimepicker'], date("Y-m-d H:i:s"), 
                null, null, 0, $ligneId, $_SESSION['usr_id'], $_POST['sap_id'], $niveau['niveauxpannes_codeArret'], $niveau['niveauxpannes_id'], $loc, $tranche, $nbreSections);



            //Persist object created
            $result = $panneEvenementMapper->persist($newPanneEvenement); 

            if($result === false)
                throw new Exception("Impossible d'enregistrer la panne/évènement", 1);

            else
                $_SESSION['message'] = "Panne/évènement bien enregistré!";

            if (isset($_POST['ConfirmerSaisir']))
                $this->afficherPanneEvenementSaisie();
            else
                $this->afficherPanneEvenementHistorique();
        } 
        catch(Exception $e)
        {
            
            $_SESSION['message'] = $e->getMessage();

            $this->afficherPanneEvenementHistorique();
        }

       
    }
        
    /**
     * Allows to update (edit) a specific panne & event in historical dataTables
     * @return Success or Error of update
     */
    public function editPanneEvenement()
    { 

        $panneEvenementMapper = new PanneEvenementMapper($this->connexion);
        $niveauxFinder = new NiveauxFinder($this->connexion);
    

        //Get the field of the table to update it
        $nameBD = $_POST['nameBD'];
        //Get the value that user wants to update
        $elementToUpdate = preg_replace("/\r\n/",' - ',$_POST['elementToUpdate']);

        try
        {
            $result = $panneEvenementMapper->editEvent($_POST['idRecording'], htmlspecialchars($elementToUpdate, ENT_QUOTES), $nameBD,date("Y-m-d H:i:s"));

            if($result === false)
                throw new Exception("Impossible de modifier", 1);

            // Utilisé pour MAJ localisation (champ localisation + champ fk_niveaupanne_id)
            if($_POST['elementToUpdate2'] != "") {
                $result2 = $panneEvenementMapper->editEvent($_POST['idRecording'], htmlspecialchars($_POST['elementToUpdate2'], ENT_QUOTES), $_POST['nameBD2'],date("Y-m-d H:i:s"));

                if($result2 === false)
                    throw new Exception("Impossible de modifier", 1);
            }

            $_SESSION['message'] = "Modification enregistrée!";

            $this->afficherPanneEvenementHistorique();
        }
        catch(Exception $e)
        {
            $_SESSION['message'] = $e->getMessage();

            $this->afficherPanneEvenementHistorique();
        }
     
    }

    /**
     * When a user wants to delete a recording in BDD's table PanneEvenement.
     *
     * @return Success or Error of delete
     */
    public function deletePanneEvenement()
    {
    
        $panneEvenementMapper = new PanneEvenementMapper($this->connexion);

        $tabErreur=array();

        try
        {
            $result = $panneEvenementMapper->remove($_GET['idRecording']);

             if($result === false)
                throw new Exception("Impossible de supprimer", 1);

            else
                $_SESSION['message'] = "Suppression effectuée!";

            $this->afficherPanneEvenementHistorique();
        }
        catch(Exception $e)
        {
            $_SESSION['message'] = $e->getMessage();

            $this->afficherPanneEvenementHistorique();
        }

    }

    /**
     * Search all user which has the role FMU on the dropDown list for create or update a panne & event
     *
     * @return user's id, user's name and user's surname
     */
    public function RechercheUtilisateurFMUPanneEvenement()
    {
        $utilisateurFinder = new UtilisateurFinder($this->connexion); 

        if($_GET['listeUtilisateurFMU'] == 0)
        {
            /*$listeUtilisateurFMU = $utilisateurFinder->findAllFMU();

            for($i=0; $i<count($listeUtilisateurFMU); $i++ )
            {
                echo ($listeUtilisateurFMU[$i]['usr_id']."$".$listeUtilisateurFMU[$i]['usr_nom']."$".
                      $listeUtilisateurFMU[$i]['usr_prenom']."$");  
            }*/

            return $utilisateurFinder->findAllByFunction("FMU");
            exit();
        }

    }


    /**
    *   Récupère le taux de pannes par service pour une période donnée
    *   @param $_GET (service, date_début_periode, date_fin_période)
    *   @return JSON
    */
    function getStatsPanneEvenement() {

        try{
            
            $panneEvenementFinder = new PanneEvenementFinder($this->connexion); 
            $ligneFinder = new LigneFinder($this->connexion); 
             
            // On récupère les niveaux d'un service (affichage d'un graph. par niveau)   
            $niveaux = $panneEvenementFinder->findNiveauxByService($_GET['service']);

            if($_GET['four'] != 100)
                $lignes = $ligneFinder->getLignesByFour($_GET['four']);
            else
                $lignes = $ligneFinder->getLignes();

            // Ce tableau contiendra les pannes pour chaque niveau
            $nivPannes = array();


            // Pour chaque niveau, on récupère les pannes de la période
            foreach ($niveaux as $n) {
      
                if($_GET['service'] != "D24") {
                    // On construit un tableau sans doublons à partir des niveaux. Chaque niveau sera un graph.
                    if($n['niveauxpannes_niveau'] != ""){

                        $nivPannes[$n['niveauxpannes_niveau']] = $panneEvenementFinder->findPannesByFourAndDateAndLocalisation($_GET['four'], $_GET['dateDebut'], $_GET['dateFin'], $n['niveauxpannes_id']);


                    }
                    elseif ($n['niveauxpannes_sscategorie'] != "") {

                        $nivPannes[$n['niveauxpannes_sscategorie']] = $panneEvenementFinder->findPannesByFourAndDateAndLocalisation($_GET['four'], $_GET['dateDebut'], $_GET['dateFin'], $n['niveauxpannes_id']);

                    }
                    else {

                        $nivPannes[$n['niveauxpannes_categorie']] = $panneEvenementFinder->findPannesByFourAndDateAndLocalisation($_GET['four'], $_GET['dateDebut'], $_GET['dateFin'], $n['niveauxpannes_id']);

                    }
                }
                else {
                    // Pour le secteur froid, on ne prend en compte que le niveau 1
                    
                    $pannes = $panneEvenementFinder->findPannesByFourAndDateAndLocalisation($_GET['four'], $_GET['dateDebut'], $_GET['dateFin'], $n['niveauxpannes_id']);

                  

                    if($n['niveauxpannes_sscategorie'] != "") {
                        if(isset($nivPannes[$n['niveauxpannes_sscategorie']])) {
                            foreach ($pannes as $p) 
                                array_push($nivPannes[$n['niveauxpannes_sscategorie']], $p);
                        }
                        else
                            $nivPannes[$n['niveauxpannes_sscategorie']] = $pannes;
                    }
                    else {
                        if(isset($nivPannes[$n['niveauxpannes_categorie']])) {
                            foreach ($pannes as $p) 
                                array_push($nivPannes[$n['niveauxpannes_categorie']], $p);
                        }
                        else
                            $nivPannes[$n['niveauxpannes_categorie']] = $pannes;
                    }
            
                }

            }

 
            if(empty($nivPannes)) 
                throw new Exception("Pas de résultats");
            
           
            $nivTps = array();

            $moisDebut = intval(substr($_GET['dateDebut'], 5, 2));
            $moisFin = intval(substr($_GET['dateFin'], 5, 2));
            $anneeDebut = intval(substr($_GET['dateDebut'], 2, 2));
            $anneeFin = intval(substr($_GET['dateFin'], 2, 2));

            // Si la période est <= 1 mois, affichage des valeurs / mois. Sinon, affichage / semaine
            if($moisDebut - $moisFin != 0) {

                $mois = array(1=>"Jan.",2=>"Fev.",3=>"Mars",4=>"Avr.",5=>"Mai",6=>"Juin",7=>"Juil.",8=>"Aout",9=>"Sept.",10=>"Oct.",11=>"Nov.",12=>"Dec.");


                foreach ($nivPannes as $niv => $pan) {
               
                    $debut = $moisDebut;
                    
                    for ($i=$anneeDebut; $i <= $anneeFin; $i++) { 

                        if ($i == $anneeFin)
                            $fin = $moisFin;
                        else if ($i < $anneeFin)
                            $fin = 12;

                        for ($j = $debut; $j <= $fin ; $j++) { 
                            foreach ($lignes as $l) {
                                $nivTps[$l['lig_numero']][$niv][$mois[$j].' '.$i] = 0;
                            }

                            $nivTps[0][$niv][$mois[$j].' '.$i] = 0;
                        }

                        $debut = 1;
                    }   

                    foreach ($pan as $p) {
                    
                        $moisPanne = intval(substr($p['pan_datepannevenement'], 5, 2));
                        $anneePanne = intval(substr($p['pan_datepannevenement'], 2, 2));
                    
                        if($_GET['typeDonnee'] == "Temps d'arrêt machine") {

                            $nivTps[$p['lig_numero']][$niv][$mois[$moisPanne].' '.$anneePanne] += $p['pan_tps_arret'];
                        
                            $nivTps[0][$niv][$mois[$moisPanne].' '.$anneePanne] += $p['pan_tps_arret'];

                        }
                        else if($_GET['typeDonnee'] == "Taux d'arrêt machine") {

                            // Pour calculer le taux d'arret, on recupère le nb de sections de la machine
                            switch($p['lig_numero']){

                                case 51:
                                    $nbTotalSections = 10;
                                    break;
                                case 52:
                                    $nbTotalSections = 10;
                                    break;
                                case 53:
                                    $nbTotalSections = 16;
                                    break;
                                case 54:
                                    $nbTotalSections = 12;
                                    break;
                                case 55:
                                    $nbTotalSections = 12;
                                    break;
                                case 81:
                                    $nbTotalSections = 12;
                                    break;
                                case 82:
                                    $nbTotalSections = 12;
                                    break;
                                default :
                                    $nbTotalSections = 1;
                                    break;
                            }

                            // Conversion de la période en minutes
                            $debut = date_create($_GET['dateDebut']);
                            $fin = date_create($_GET['dateFin']);
                            $duree = date_diff($debut, $fin);
                            $duree = $duree->d*1140 + $duree->h*60;

                            $loc = explode(" - ", $p['pan_localisation']);

                            //Calcul et stockage du tps d'arret, nb sections pris en compte
                            if($loc[0] == 'Chaud' && $loc[1] == 'Machine') {

                                // Calcul du taux de pannes par niveau pour la période donnée : (A chaud) tpsSection = tpsArret * nbSectionsArretees / nbSectionsTotalesMachine   (A chaud et a froid) tauxArret = Somme_des_tpsSection (ou tpsArret à froid) / tpsPériode * 100
                                $value = $p['pan_tps_arret'] * $p['pan_nb_sections'] / $nbTotalSections;
                                $value = round($value / $duree * 100, 2);

                                $nivTps[$p['lig_numero']][$niv][$mois[$moisPanne].' '.$anneePanne] += $value;

                                $nivTps[0][$niv][$mois[$moisPanne].' '.$anneePanne] += $value;
                            }
                            else {

                                $value = round($p['pan_tps_arret'] / $duree * 100, 2);

                                $nivTps[$p['lig_numero']][$niv][$mois[$moisPanne].' '.$anneePanne] += $value;
                                $nivTps[0][$niv][$mois[$moisPanne].' '.$anneePanne] += $value;
                            }

                        }
                        else {

                             // Pour calculer le taux d'arret, on recupère le nb de sections de la machine
                            switch($p['lig_numero']){

                                case 51:
                                    $nbTotalSections = 10;
                                    break;
                                case 52:
                                    $nbTotalSections = 10;
                                    break;
                                case 53:
                                    $nbTotalSections = 16;
                                    break;
                                case 54:
                                    $nbTotalSections = 12;
                                    break;
                                case 55:
                                    $nbTotalSections = 12;
                                    break;
                                case 81:
                                    $nbTotalSections = 12;
                                    break;
                                case 82:
                                    $nbTotalSections = 12;
                                    break;
                                default :
                                    $nbTotalSections = 1;
                                    break;
                            }

                            // Conversion de la période en minutes
                            $debut = date_create($_GET['dateDebut']);
                            $fin = date_create($_GET['dateFin']);
                            $duree = date_diff($debut, $fin);
                            $duree = $duree->d*1140 + $duree->h*60;

                            $loc2 = explode(" - ", $p['pan_localisation']);

                            if($loc2[0] == 'Chaud' && $loc2[1] == 'Machine') {

                                $value = ($p['pan_tps_arret'] + $p['pan_tps_casse']) * $p['pan_nb_sections'] / $nbTotalSections;
                                $value = round($value / $duree * 100, 2);

                                $nivTps[$p['lig_numero']][$niv][$mois[$moisPanne].' '.$anneePanne] += $value;

                                $nivTps[0][$niv][$mois[$moisPanne].' '.$anneePanne] += $value;

                            }
                            else if($loc2[0] == 'Chaud' || $loc2[0] == 'Changement de fabrication') {

                                $value = $p['pan_tps_arret'] + $p['pan_tps_casse'];
                                $value = round($value / $duree * 100, 2);

                                $nivTps[$p['lig_numero']][$niv][$mois[$moisPanne].' '.$anneePanne] += $value;

                                $nivTps[0][$niv][$mois[$moisPanne].' '.$anneePanne] += $value; 
                            }
                            else {


                                $value = round($p['pan_tps_casse'] / $duree * 100, 2);

                                $nivTps[$p['lig_numero']][$niv][$mois[$moisPanne].' '.$anneePanne] += $value;
                                $nivTps[0][$niv][$mois[$moisPanne].' '.$anneePanne] += $value;
                            }
                        }

                    }
                }
            }
            else {

                $dateDebut = new DateTime($_GET['dateDebut']);
                $semDebut = $dateDebut->format("W");
                $dateFin = new DateTime($_GET['dateFin']);
                $semFin = $dateFin->format("W");


                foreach ($nivPannes as $niv => $pan) {

                    for ($i=$semDebut; $i <= $semFin; $i++) { 

                        foreach ($lignes as $l) {
                            $nivTps[$l['lig_numero']][$niv]['Sem. '.$i] = 0;
                        }

                        $nivTps[0][$niv]['Sem. '.$i] = 0;
                      
                    } 

                    foreach ($pan as $p) {

                        $datePanne = new DateTime($p['pan_datepannevenement']);
                        $semPanne = $datePanne->format("W");
                        
                        $moisPanne = intval(substr($p['pan_datepannevenement'], 5, 2));
                        $anneePanne = intval(substr($p['pan_datepannevenement'], 2, 2));
                        
                        if($_GET['typeDonnee'] == "Temps d'arrêt machine") {

                            $nivTps[$p['lig_numero']][$niv]['Sem. '.$semPanne] += $p['pan_tps_arret'];
                            
                            $nivTps[0][$niv]['Sem. '.$semPanne] += $p['pan_tps_arret'];
                        }
                        else if($_GET['typeDonnee'] == "Taux d'arrêt machine") {

                            // Pour calculer le taux d'arret, on recupère le nb de sections de la machine
                            switch($p['lig_numero']){

                                case 51:
                                    $nbTotalSections = 10;
                                    break;
                                case 52:
                                    $nbTotalSections = 10;
                                    break;
                                case 53:
                                    $nbTotalSections = 16;
                                    break;
                                case 54:
                                    $nbTotalSections = 12;
                                    break;
                                case 55:
                                    $nbTotalSections = 12;
                                    break;
                                case 81:
                                    $nbTotalSections = 12;
                                    break;
                                case 82:
                                    $nbTotalSections = 12;
                                    break;
                                default :
                                    $nbTotalSections = 1;
                                    break;
                            }

                            // Conversion de la période en minutes
                            $debut = date_create($_GET['dateDebut']);
                            $fin = date_create($_GET['dateFin']);
                            $duree = date_diff($debut, $fin);
                            $duree = ($duree->d+1)*1440 + $duree->h*60;
                            
                            $loc = explode(" - ", $p['pan_localisation']);

                            //Calcul et stockage du tps d'arret, nb sections pris en compte
                            if($loc[0] == 'Chaud' && $loc[1] == 'Machine') {

                                // Calcul du taux de pannes par niveau pour la période donnée : (A chaud) tpsSection = tpsArret * nbSectionsArretees / nbSectionsTotalesMachine   (A chaud et a froid) tauxArret = Somme_des_tpsSection (ou tpsArret à froid) / tpsPériode * 100
                                $value = $p['pan_tps_arret'] * $p['pan_nb_sections'] / $nbTotalSections;
                                $value = round($value / $duree * 100, 2);

                                $nivTps[$p['lig_numero']][$niv]['Sem. '.$semPanne] += $value;

                                $nivTps[0][$niv]['Sem. '.$semPanne] += $value;
                            }
                            else {

                                $value = round($p['pan_tps_arret'] / $duree * 100, 2);

                                $nivTps[$p['lig_numero']][$niv]['Sem. '.$semPanne] += $value;
                                $nivTps[0][$niv]['Sem. '.$semPanne] += $value;
                            }

                        }
                        else {

                            // Pour calculer le taux d'arret, on recupère le nb de sections de la machine
                            switch($p['lig_numero']){

                                case 51:
                                    $nbTotalSections = 10;
                                    break;
                                case 52:
                                    $nbTotalSections = 10;
                                    break;
                                case 53:
                                    $nbTotalSections = 16;
                                    break;
                                case 54:
                                    $nbTotalSections = 12;
                                    break;
                                case 55:
                                    $nbTotalSections = 12;
                                    break;
                                case 81:
                                    $nbTotalSections = 12;
                                    break;
                                case 82:
                                    $nbTotalSections = 12;
                                    break;
                                default :
                                    $nbTotalSections = 1;
                                    break;
                            }

                            // Conversion de la période en minutes
                            $debut = date_create($_GET['dateDebut']);
                            $fin = date_create($_GET['dateFin']);
                            $duree = date_diff($debut, $fin);
                            $duree = ($duree->d+1)*1440 + $duree->h*60;
                            
                            $loc = explode(" - ", $p['pan_localisation']);

                            //Calcul et stockage du tps d'arret, nb sections pris en compte
                            if($loc[0] == 'Chaud' && $loc[1] == 'Machine') {

                                $value = ($p['pan_tps_arret'] + $p['pan_tps_casse']) * $p['pan_nb_sections'] / $nbTotalSections;
                                $value = round($value / $duree * 100, 2);

                                $nivTps[$p['lig_numero']][$niv]['Sem. '.$semPanne] += $value;

                                $nivTps[0][$niv]['Sem. '.$semPanne] += $value;
                            }
                            else if($loc[0] == 'Chaud' || $loc[0] == 'Changement de fabrication') {

                                $value = $p['pan_tps_arret'] + $p['pan_tps_casse'];
                                $value = round($value / $duree * 100, 2);

                                $nivTps[$p['lig_numero']][$niv]['Sem. '.$semPanne] += $value;

                                $nivTps[0][$niv]['Sem. '.$semPanne] += $value;
                            }
                            else {

                                $value = round($p['pan_tps_casse'] / $duree * 100, 2);

                                $nivTps[$p['lig_numero']][$niv]['Sem. '.$semPanne] += $value;
                                $nivTps[0][$niv]['Sem. '.$semPanne] += $value;
                            }
                        }

                    }
                }

            }

           
            

           

            

            

            
       
            echo json_encode($nivTps);
        }
        catch (Exception $e){
            echo '{"Erreur":"'.$e->getMessage().'"}';
        }
    }
}
?>

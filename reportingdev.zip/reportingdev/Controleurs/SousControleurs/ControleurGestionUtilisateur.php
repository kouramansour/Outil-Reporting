<?php

session_cache_limiter('private_no_expire, must-revalidate');

/**
 * This class ControleurGestionUtilisateur allows to manage all module management user's actions.
 * @since 26 août 2016
 * @package SousControleurs
 * @author Jordan PROTIN <Jordan.Protin@yahoo.com> 
 */
class ControleurGestionUtilisateur
{

    public static $lesDroits = array();

    /**
     * Class's constructor.
     *
     * @return Function[name] Call the good function according action
     */
    public function __construct()
    {

        $_SESSION['page'] = "utilisateurs";


        /* create new logins for ALL users
        $utilisateurMapper = new UtilisateurMapper($connexion);
           
        $utilisateurMapper->encodeUserLogin();*/

        
        
        $tabErreur = array();
        $action = Nettoyage::ClearString($_GET['action']);

        //Check if the user has the necessary rights for this module
        if ($_SESSION['usr_role'] != "Admin" && !checkRights(12, "Read")) 
        { 
            header('Location:./'); 
        }
        
        //By default, first $action called is 'afficherGestionUtilisateur'
        $this->$action(); 
        exit();
    }

    /**
     * Allows a user to display the user management page of the application.
     *
     * @return The user management page
     */
    public function afficherGestionUtilisateur()
    {
        

        //Recheck if the user is really an administrator
        if($_SESSION['usr_role'] != "Admin" && !checkRights(12, "Read"))
        {
            require ('./Views/templates/Erreur/erreurAuthentification.php');
        }
        else
        {
            $connexion = new Connexion;
            $acteurFinder = new ActeurFinder($connexion);

            $acteurs = $acteurFinder->getActeurs();

            $_SESSION['acteurs'] ="";

            foreach($acteurs as $a ) {

                    $_SESSION['acteurs'] .= '<OPTION value="'.$a['idActeur'].'">'.$a['nomActeur'].'</OPTION>';
            } 

            require ('./Views/templates/Utilisateur/Utilisateur.php');
        }
    }                                   

    /**
     * Allows to display all user in the dropDown list.
     *
     * @return The user's id, user's name and user's surname
     */
    public function RechercheGestionUtilisateurNonAdmin()
    {

        //Recheck if the user is really an administrator
        if($_SESSION['usr_role'] != "Admin" && !checkRights(12, "Read"))
        {
            require ('./Views/templates/Erreur/erreurAuthentification.php');
        }
        else
        {

            $connexion = new Connexion;
            $utilisateurMapper = new UtilisateurMapper($connexion);
            $utilisateurFinder = new UtilisateurFinder($connexion);


            if($_GET['listeUtilisateurNonAdmin'] == 0)
            {

                $listeUtilisateurNonAdmin = $utilisateurFinder->findAllUtilisateur();

                for($i=0; $i<count($listeUtilisateurNonAdmin); $i++ )
                {
                    echo ($listeUtilisateurNonAdmin[$i]['usr_id']."$".$listeUtilisateurNonAdmin[$i]['usr_nom']."$".
                          $listeUtilisateurNonAdmin[$i]['usr_prenom']."$");    
                }
                exit();
            }
            //If user don't want to search all user in dropDown list, other way is that he wants to delete a specific user
            else
            {
                $utilisateurMapper->remove($_GET['utilisateurIndex']);
            }
        }
    }    



    /**
     * When a user wants to insert a recording in BDD's table Utilisateur.
     *
     * @return Function 'traiterVariablePost' after verification of user's identity
     */
    public function updateGestionUtilisateur()
    {

    
        //Recheck if the user is really an administrator
        if($_SESSION['usr_role'] != "Admin" && !checkRights(12, "Update"))
        {
            require ('./Views/templates/Erreur/erreurAuthentification.php');
        }
        else
        {
            $this->traiterVariablesPost();
        }
    }

    /**
     * Allows to check differents variables which represents data user from the view
     *
     * @return Function 'gestionUtilisateur' after verification of user's data entered
     */
    public function traiterVariablesPost()
    {
        if(!isset($_POST['formName'])) {

            $_SESSION['erreur_message'] = null;
            $tabErreur = array();

            $resultCheckNom = checkInput($_POST['nom'], '/^[a-zÜ-ü\s]{2,40}$/', "Nom");
            $resultCheckPrenom = checkInput($_POST['prenom'], '/^[a-zÜ-ü\s]{2,40}$/', "Prenom");
            
            $resultCheckFonction2 = checkInput($_POST['fonction2'], '/^(STAFF|CB|FMU|CG|AQ|R|AQR|Pilote|MV|GQ|D12|D24|Qualité|Ordo|MPF|LANCEUR CHAUD|LANCEUR FROID|FEEDERISTE)?$/', "Fonction2");
            $resultCheckRole = checkInput($_POST['role'], '/^[a-zA-Z]{1,6}$/', "Role");

            array_push($tabErreur, $resultCheckNom, $resultCheckPrenom, $resultCheckFonction1, $resultCheckFonction2, $resultCheckEquipe,$resultCheckRole);

            $_SESSION['erreur_message'] = $tabErreur;

            foreach ($_SESSION['erreur_message'] as $value)
            {
                if(!is_null($value))
                {
                    header('Location: ./index.php?action=afficherGestionUtilisateur');
                    exit;
                }
            }
        }

        $this->gestionUtilisateur();

    }

    /**
     * Allows to insert differents user data 
     * @return Success or Error of insert
     */
    public function gestionUtilisateur()
    {

        if(isset($_POST['formName']) && $_POST['formName'] =='rightsForm') {

            $connexion = new Connexion;
            $droitsUtilisateurMapper = new DroitsUtilisateurMapper($connexion);
            $modules = $connexion->executeQuery("SELECT * FROM modules", array());
            $acteurs = $connexion->executeQuery("SELECT * FROM acteurs", array());
    
            // Si les droits ne sont pas séléctionés (cases cochées), on enlève les droits
            foreach ($acteurs as $a) {

                foreach ($modules as $m) {
                
                    if(!isset($_POST["$".$a['idActeur'].'_'.$m['idModule'].'_Read'])){
                        
                        $droitsUtilisateur = new DroitsUtilisateur($a['idActeur'],$m['idModule'],'Read');
                        $droitsUtilisateurMapper->remove($droitsUtilisateur);

                    }

                    if (!isset($_POST["$".$a['idActeur'].'_'.$m['idModule'].'_Add']) ){

                        $droitsUtilisateur = new DroitsUtilisateur($a['idActeur'],$m['idModule'],'Add');
                        $droitsUtilisateurMapper->remove($droitsUtilisateur);
                    }

                    if (!isset($_POST["$".$a['idActeur'].'_'.$m['idModule'].'_Update'])){

                        $droitsUtilisateur = new DroitsUtilisateur($a['idActeur'],$m['idModule'],'Update');
                        $droitsUtilisateurMapper->remove($droitsUtilisateur);

                    }
                    if (!isset($_POST["$".$a['idActeur'].'_'.$m['idModule'].'_Delete'])) {

                        $droitsUtilisateur = new DroitsUtilisateur($a['idActeur'],$m['idModule'],'Delete');
                        $droitsUtilisateurMapper->remove($droitsUtilisateur);

                    }
                   
                }
                 
            }

            // On ajoute les droits séléctionnés (cases cochées) / Format donnée envoyée : "$idActeur_idModule_droit"
            foreach ($_POST as $key => $value) {

                if($key[0] == "$") {

                    $value = substr($value, 1);
                    $data = explode("_", $value);

                    $idActeur = $data[0];
                    $idModule = $data[1];
                    $droit = $data[2];


                    $droitsUtilisateur = new DroitsUtilisateur($idActeur,$idModule,$droit);
                    $droitsUtilisateurMapper->persist($droitsUtilisateur);
                }
            }
          
        }
        else {
            $objetGenerateurMdp = new GenerateurMdp;
            //Automatically generate an id (a password) for the new user according his surname and his name
            $identifiant = $objetGenerateurMdp->concatenerPrenomNomChiffre($_POST['prenom'], $_POST['nom']);
            
            $connexion = new Connexion;
            $utilisateurMapper = new UtilisateurMapper($connexion);
            $utilisateurFinder = new UtilisateurFinder($connexion);
            
                
            //Creation of object Utilisateur from file Utilisateur.php which represents entity Utilisateur
            $newUser = new Utilisateur(htmlspecialchars($_POST['nom'], ENT_QUOTES), htmlspecialchars($_POST['prenom'], ENT_QUOTES), 
                                       hash('sha256',$identifiant), $_POST['fonction1'], $_POST['fonction2'], 
                                       $_POST['equipe'], date("Y-m-d H:i:s"),  $_POST['role'], $_POST['ligne']);
        
            //Persist object created
            $utilisateurMapper->persist($newUser);
            $_SESSION['identifiant_nouveau_utilisateur'] = $identifiant;

            //Save all new user's parameters in SESSION variable in order to use these in the future in the application
            $lastUserSaved = $utilisateurFinder->findLastUserSaved();
            $_SESSION['nom_nouveau_utilisateur'] = $lastUserSaved[0]['usr_nom']; 
            $_SESSION['prenom_nouveau_utilisateur'] = $lastUserSaved[0]['usr_prenom'];
            $_SESSION['data_creation_nouveau_utilisateur'] = $lastUserSaved[0]['usr_create'];
        }

        header('Location: ./index.php?action=afficherGestionUtilisateur');      
    }

    /**
     * Allows to save the id (password) of the new user in a word file
     * @return Success or Error of insert in file
     */
    public function saveMdpGestionUtilisateur()
    {

        //Get all new user's parameters in order to retranscribe these in the word file
        $identifiant = $_GET['identifiant'];
        $prenom = $_GET['prenom'];
        $nom = $_GET['nom'];
        $dateCreation = ucfirst(strftime('%A %d %B %Y à %H:%M', strtotime(substr($_GET['dateCreation'],0,16))));
        $proprietaire = strtoupper($_SESSION['usr_prenom'])." ".strtoupper($_SESSION['usr_nom']);
        $dateActuelle = date('d/m/Y');
        $dateActuelleNomFic = date('d-m-Y');
        $heureActuelle = date('H:i');

        //header specify that this is for a word file
        header("Content-type: application/vnd.ms-word");
        header("Content-Disposition: attachment;Filename=identifiant_reporting-$dateActuelleNomFic.doc");

        //Content of the file
        echo "<html>";
        echo "<meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">";
        echo "<body>";
        echo "<h1 style='color:#A4A4A4;'>Document O-I Manufacturing</h1>";
        echo "<p><span style='text-decoration:underline;color:#0B173B;'>Téléchargé le</span> : $dateActuelle à $heureActuelle.</p>";
        echo "</br>";
        echo "<p><span style='text-decoration:underline;color:#0B173B;'>Depuis l'application</span> : Reporting informatique.</p>";
        echo "</br>";
        echo "<p><span style='text-decoration:underline;color:#0B173B;'>Sujet du document</span> : un nouvel utilisateur vient d'être enregistré dans l'application.</p>";
        echo "</br>";
        echo "<p>-----------------------------------------------------------------------------------------------------------------</p>";
        echo "<p><span style='text-decoration:underline;color:#0B173B;'>Date de création de l'utilisateur</span> : le $dateCreation.</p>";
        echo "</br>";
        echo "<p>Il s'agit de : <strong>$prenom $nom</strong>.</p>";
        echo "</br>";
        echo "<p>Si cette personne possède une adresse mail : <a href='mailto:$prenom.$nom@o-i.com'>Contactez-la</a></p>";
        echo "</br>";
        echo "<p>Son identifiant de connexion personnel est : <strong style='color:#8A0808;'>$identifiant</strong></p>";
        echo "</br>";
        echo "<p><strong>/!\ Veuillez lui communiquer cet identifiant dans les plus bref délais. <strong>/!\</strong></p>";
        echo "</br>";
        echo "<p>-----------------------------------------------------------------------------------------------------------------</p>";
        echo "</br>";
        echo "<p><span style='color:#0B173B;text-decoration:underline;'>Règle de confidentialité</span> : ce document est strictement confidentiel. Il est fortement recommandé au proprietaire du document de limiter son accès.</p>";
        echo "<footer><span style='color:#0B173B;text-decoration:underline;'>Propriétaire du document </span>: <strong>$proprietaire.</strong></footer>";
        echo "</body>"; 
        echo "</html>";
    }

    /**
     * Allows to update (edit) a specific user in historical dataTables
     * @return Success or Error of update
     */
    public function editGestionUtilisateur()
    {
        
        $connexion = new Connexion;
        $utilisateurMapper = new UtilisateurMapper($connexion);

        $tabErreur = array();
        $nbrErreurs =0; 

        //Get the field of the table to update it
        $nameBD = $_GET['nameBD'];
        //Get the value that user wants to update
        $elementToUpdate = $_GET['elementToUpdate'];

        try
        {
            $result = $utilisateurMapper->editUser($_GET['idRecording'], $elementToUpdate, $nameBD); 

        }
        catch(Exception $e)
        {
            $tabErreur[]="<font color='red' id='erreur'> La modification de cet utilisateur a échoué !</br>";
            $nbrErreurs++;
            require('./Views/templates/Erreur/erreur.php');
            exit();
        }
        exit();
    }

    /**
     * Allows to update (edit) an id (password) for a specific user in historical dataTables
     * @return Success or Error of update password
     */
    public function editMdpGestionUtilisateur()
    {
        $objetGenerateurMdp = new GenerateurMdp;
        //Automatically regenerate an id (a password) for the new user according his surname and his name
        $identifiant = $objetGenerateurMdp->concatenerPrenomNomChiffre($_GET['prenom'], $_GET['nom']);
        
        $connexion = new Connexion;
        $utilisateurMapper = new UtilisateurMapper($connexion);

        //To insert in correct value in dataBase
        if($_GET['ligne'] == "no")
        {
            $_GET['ligne'] = "10";
        }


        //Creation of object Utilisateur dynamically
        $userEdited = $utilisateurMapper->userUpdated($_GET['idUser'],htmlspecialchars($_GET['nom'], ENT_QUOTES), htmlspecialchars($_GET['prenom'], ENT_QUOTES),hash('sha256',$identifiant), $_GET['fonction1'], $_GET['fonction2'],$_GET['equipe'], date("Y-m-d H:i:s"), $_GET['role'], $_GET['ligne']);


        //Display the id(password) on the view
        echo $identifiant;
    }


}
?>

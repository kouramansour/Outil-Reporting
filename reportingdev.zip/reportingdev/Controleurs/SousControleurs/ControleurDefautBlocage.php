<?php

session_cache_limiter('private_no_expire, must-revalidate');

require('Librairies/PHPMailer-master/src/PHPMailer.php');
require('Librairies/PHPMailer-master/src/SMTP.php');
require('Librairies/PHPMailer-master/src/Exception.php');
/**
 * Controleur de gestion des défauts et des blocages 
 * Chaque blocage est lié à un défaut. Un défaut peut être lié à plusieurs blocages
 */
class ControleurDefautBlocage
{

    /**
     * Constructeur
     */
    public function __construct()
    {  
        $_SESSION['page'] = "defauts";
   
        $action = Nettoyage::ClearString($_GET['action']);


        if (!$_SESSION['usr_role'] == "Admin" || !$_SESSION['usr_role'] == "User") 
        { 
            header('Location:./'); 
        }
        

        $this->$action(); exit();
    }

	/**
     * Affiche la fenetre de saisie d'un défaut
     */
    public function afficherDefautBlocageSaisie()
    {
        
        require('./Views/templates/DefautBlocage/DefautBlocageSaisie.php');

        unset($_SESSION['message']);
    } 

    public function afficherDefautBlocageRqSaisie()
    {
        
        require('./Views/templates/DefautBlocage/DefautBlocageRqSaisie.php');

        unset($_SESSION['message']);
    } 
	
    /**
     * Affiche la liste des défauts saisis
     */
    public function afficherDefautBlocage()
    {
       
        if(isset($_GET['resetLineSessionCommun']))
          unset($_SESSION['lig_num']);

        require('./Views/templates/DefautBlocage/DefautBlocageHistorique.php');

        unset($_SESSION['message']);

    }  



    /**
     * Enregistre un nouveau défaut
     */
    public function ajouterDefautBlocage() 
    {   

        $connexion = new Connexion; 
        $defautMapper = new DefautMapper($connexion); 
        $defautFinder = new DefautFinder($connexion);
        $defautConnuFinder = new DefautsConnusFinder($connexion);
        $userFinder = new UtilisateurFinder($connexion);

        try {

            if(empty($_POST['date']) OR empty($_POST['secteur']) OR empty($_POST['defautconnu'])) 
                throw new Exception("Veuillez remplir tous les champs obligatoires");

            $defautConnuId = $_POST['defautconnu'];
            $defConnu = $defautConnuFinder->findById($defautConnuId)[0];

            if ($defConnu['defautconnu_type'] == "CRITIQUE") {
                $derniereFiche = $defautFinder->findNumeroFiche();

                if($derniereFiche === false)
                    throw new Exception("Impossible d'enregistrer le défaut critique", 1);

                $fiche = $derniereFiche[0]["MAX(`def_fiche`)"]+1;

            }
            else 
                $fiche = "--";
            
            $sap_code = "";

            if (isset($_POST['fabDesc'])){
                $sap_id = $_POST['fabDescSapId'];
                $sap_num = $_POST['fabDescSapNum'];
                $sap_libelle = $_POST['fabDescSapLibelle'];
                $sap_code = $_POST['fabDescSapCode'];
            }
            else {
                $sap_id = $_POST['sap_id'];
                $sap_num = $_POST['sap_num'];
                $sap_libelle = $_POST['sap_libelle'];
                $sap_code = $_POST['sap_code_forme'];
            }

            $action = addslashes(preg_replace("/\r\n/",' - ',$_POST['action']));
            $origine = addslashes(preg_replace("/\r\n/",' - ',$_POST['origine']));
            $coms = addslashes(preg_replace("/\r\n/",' - ',$_POST['commentaires']));
            
          
            $newDefaut = new Defaut(null, $_POST['secteur'], $defautConnuId, $origine, $action, $_POST['moule'], $_POST['bague'], $_POST['section'], $fiche, $_POST['date'], date('Y-m-d H:i', time()), null, $sap_id, $_POST['lig_id'], $_SESSION['usr_id'], $coms);

            $result = $defautMapper->persist($newDefaut);

            if($result === false)
                throw new Exception("Impossible d'enregistrer le défaut", 1);

            $defId = $defautFinder->findLastDefId();

            if($result === false)
                throw new Exception("Impossible de bloquer directement", 1);

            
                
            if ($defConnu['defautconnu_type'] == "CRITIQUE") {
                $_SESSION['message'] ="Défaut critique ajouté sur la ligne ".$_POST['ligne']." ! (fiche n° ".$fiche. ")";

                //Déclaration des variables pour envoi d'une notification (effectuée avec ajax après chargement de la page si $_SESSION['mail'] existe)
               

            
                $_SESSION['mail']['subject'] = 'Défaut '.$defConnu['defautconnu_type'].' trouvé sur la ligne '.$_POST['ligne'];

                $_SESSION['mail']['mess'] = '<html>'.
                          '<head>'.
                           '<title>REPORTING - Défaut '.$defConnu['defautconnu_type'].'</title>'.
                           '<meta charset=\'UTF-8\'>'.
                          '</head>'.
                          '<body>'.
                            '<h2> Le défaut suivant a été trouvé sur la ligne '.$_POST['ligne'].' :</h2>'.
                            '<p>'.
                            'Date : '.$_POST['date'].'<br/>'.
                            'Nom : '. $defConnu['defautconnu_nom'].'<br/>'.
                            'Type : '.$defConnu['defautconnu_type'].'</p>'.
                            '<p>'.
                            'Secteur : '.$_POST['secteur'].'<br/>'.
                            'Section : '.$_POST['section'].'<br/>'.
                            'Moule : '.$_POST['moule'].'<br/>'.
                            'Bague : '.$_POST['bague'].'</p>'.
                            '<p>'.
                            'Origine : '.$origine.'<br/>'.
                            'Action corrective : '.$action.'<br/>'.
                            'Commentaires : '.$coms.
                          '</body>'.
                        '</html>';

                
                // Cherche le line leader de la ligne à notifier
                $usr = $userFinder->findUserBy(array('usr_fk_lig_id' => $_POST['lig_id'], 'fk_usr_fonction1' => 8));

                $_SESSION['mail']['to'] = "";
                foreach ($usr as $u) {
                    if($u['usr_mail'] != "")
                        $_SESSION['mail']['to'] .= $u['usr_mail'].',';
                }
                $_SESSION['mail']['to'] = substr($_SESSION['mail']['to'], 0, -1);

            }
            else
                $_SESSION['message'] ="Défaut ajouté sur la ligne ".$_POST['ligne']." !";


            $this->afficherDefautBlocage();
            
            if($_POST['Confirmer'] == 'ConfirmerBloquer') {

                $defId = $defautFinder->findLastDefId();
                if($defId == "")
                    throw new Exception("Impossible de récupérer le défaut pour bloquer", 1);

                $def = array($defId[0]['def_id'], $_POST['date'], $_POST['ligne'], $sap_num, $sap_code, $sap_libelle, $defautConnuId, $defConnu['defautconnu_type'], $_POST['secteur'], $origine,$action, $_POST['moule'], $_POST['section'], $_POST['bague'], null, null, $_POST['commentaires'], $_SESSION['usr_id'], $_POST['lig_id'], $sap_id);

                echo "<script>";
                echo "showWindowAddBlocage(".json_encode($def).");";
                echo "</script>";

            } 


            
        } 
        catch (Exception $e)
        {
            $_SESSION['message'] = $e->getMessage();

            $this->afficherDefautBlocage();
        }

    }

    /**
     * Enregistre un nouveau rapport qualite
     */
    public function ajouterRqDefautBlocage() 
    {   

        $connexion = new Connexion; 
        $rqFinder = new RapportQualiteFinder($connexion);
        $rqMapper = new RapportQualiteMapper($connexion);

        try {

            $rq = $rqFinder->findRqByDate($_POST['date']);

            if($rq) 
                throw new Exception("Un rapport existe déjà pour cette date !");

            $L51M = addslashes(preg_replace("/\r\n/",' - ',$_POST['L51M']));
            $L51AM = addslashes(preg_replace("/\r\n/",' - ',$_POST['L51AM']));
            $L51S = addslashes(preg_replace("/\r\n/",' - ',$_POST['L51S']));

            $L52M = addslashes(preg_replace("/\r\n/",' - ',$_POST['L52M']));
            $L52AM = addslashes(preg_replace("/\r\n/",' - ',$_POST['L52AM']));
            $L52S = addslashes(preg_replace("/\r\n/",' - ',$_POST['L52S']));

            $L53M = addslashes(preg_replace("/\r\n/",' - ',$_POST['L53M']));
            $L53AM = addslashes(preg_replace("/\r\n/",' - ',$_POST['L53AM']));
            $L53S = addslashes(preg_replace("/\r\n/",' - ',$_POST['L53S']));

            $L54M = addslashes(preg_replace("/\r\n/",' - ',$_POST['L54M']));
            $L54AM = addslashes(preg_replace("/\r\n/",' - ',$_POST['L54AM']));
            $L54S = addslashes(preg_replace("/\r\n/",' - ',$_POST['L54S']));

            $L55M = addslashes(preg_replace("/\r\n/",' - ',$_POST['L55M']));
            $L55AM = addslashes(preg_replace("/\r\n/",' - ',$_POST['L55AM']));
            $L55S = addslashes(preg_replace("/\r\n/",' - ',$_POST['L55S']));

            $L81M = addslashes(preg_replace("/\r\n/",' - ',$_POST['L81M']));
            $L81AM = addslashes(preg_replace("/\r\n/",' - ',$_POST['L81AM']));
            $L81S = addslashes(preg_replace("/\r\n/",' - ',$_POST['L81S']));

            $L82M = addslashes(preg_replace("/\r\n/",' - ',$_POST['L82M']));
            $L82AM = addslashes(preg_replace("/\r\n/",' - ',$_POST['L82AM']));
            $L82S = addslashes(preg_replace("/\r\n/",' - ',$_POST['L82S']));

            $divers = addslashes(preg_replace("/\r\n/",' - ',$_POST['divers']));

            $rapport = new RapportQualite(null, $_POST['date'], $L51M,$L51AM,$L51S, $L52M,$L52AM,$L52S, $L53M,$L53AM,$L53S, $L54M,$L54AM,$L54S, $L55M,$L55AM,$L55S, $L81M,$L81AM,$L81S, $L82M,$L82AM,$L82S, $divers, $_SESSION['usr_id'], date('Y-m-d', time()));

            $result = $rqMapper->persist($rapport);

            if($result === false)
                throw new Exception("Impossible de créer le rapport", 1);

            
            $_SESSION['message'] ="Rapport du ".$_POST['date']." créé !";


            $this->afficherDefautBlocage();
            
            
        } 
        catch (Exception $e)
        {
            $_SESSION['message'] = $e->getMessage();

            $this->afficherDefautBlocage();
        }

    }

    /**
     * Envoie une notification
     */
    public function notifierDefautBlocage()
    {  
        // Envoi d'une notification au line leader de la ligne
        $mail = new PHPMailer\PHPMailer\PHPMailer();
        $mail->IsSMTP(); // enable SMTP
        $mail->CharSet = 'UTF-8';
        $mail->IsHTML(true);
        $mail->SMTPDebug = 0; // debugging: 1 = errors and messages, 2 = messages only
        $mail->SMTPAuth = true; // authentication enabled
        $mail->SMTPSecure = MAILPROTOCOL; // secure transfer enabled REQUIRED for Gmail
        $mail->Host = MAILHOST;
        $mail->Port = MAILPORT; // or 587
        $mail->IsHTML(true);
        $mail->Username = MAILUSR;
        $mail->Password = MAILPASS;

        //Set who the message is to be sent from
        $mail->setFrom(MAILFROM);
        $mail->addReplyTo('noreply@o-i.com');
        $mail->addAddress($_POST['to']);
        //$mail->addAddress('stagiairejcc.pgm@o-i.com'); pour m'envoyer le mail pour test
        $mail->Subject = $_POST['subject'];
        $mail->Body = $_POST['mess'];
       
        $mail->send();
        
        unset($_SESSION['mail']);

    }    


    
    /**
     * Enregistre un nouveau blocage à partir d'un défaut
     */
    public function bloquerDefautBlocage()
    {   

        $connexion = new Connexion; 
        $blocageMapper = new BlocageMapper($connexion); 
        $blocageFinder = new BlocageFinder($connexion); 


        try {

            if(empty($_GET['date1']) OR empty($_GET['lot']) OR empty($_GET['qte']) ) 
                throw new Exception("Veuillez remplir tous les champs obligatoires");

            $motif = addslashes(preg_replace("/\r\n/",' - ',$_GET['motif']));
            $coms = addslashes(preg_replace("/\r\n/",' - ',$_GET['commentaires']));

            if($_GET['statut1'] != "BLOQUEE") {
                $traitees = $_GET['qte'];
                $restantes = 0;
                $etat = "Terminé";
            }
            else {
                $traitees = 0;
                $restantes = $_GET['qte'];
                $etat = "En cours";
            }

            $palDebut = sprintf('%03d', $_GET['palDebut']);
            $palFin = sprintf('%03d', $_GET['palFin']);
            $lot = sprintf('%03d', $_GET['lot']);

            $statut1 = '<b>'.$_GET['statut1'].' ('.$_GET['qte'].') : </b> pal. '.$palDebut.' à '.$palFin;
          
            $blocage = new Blocage($lot, $palDebut, $palFin, $_GET['qte'], $etat, $coms, $_GET['date1'], date('Y-m-d H:i', time()), null, $_SESSION['usr_id'], $_GET['defId'], $_GET['motif'], $traitees, $restantes, $statut1);

            $result = $blocageMapper->persist($blocage);

            if($result === false)
                throw new Exception("Impossible d'enregistrer le blocage (lot n°".$_GET['lot'].")", 1);
            

            // get the last blocage's id
            $blocId = $blocageFinder->findLastBlocageByDef($_GET['defId'])[0];

            if($blocId['bloc_id'] === false)
                throw new Exception("Impossible de bloquer les palettes", 1);

            $this->blocPal($blocId['bloc_id'], $_GET['lot'], $_GET['palDebut'], $_GET['palFin'], $_GET['statut1']);

            $_SESSION['message'] ="Défaut n° ".$_GET['defId']." : <br/>Palettes n° ".$_GET['palDebut']." à ".$_GET['palFin']." (lot ".$_GET['lot'].") ".$_GET['statut1'];




            // remplissage de la table blocagesHistorique
           
            $blocHistMapper = new BlocagesHistoriqueMapper($connexion); 

            $hist = new BlocagesHistorique(null, $blocId['bloc_id'], $_SESSION['usr_id'], "BLOCAGE", date('Y-m-d H:i', time()), $statut1);

            $result = $blocHistMapper->persist($hist);

            if($result === false)
                throw new Exception("Impossible d'enregistrer l'historique");
            

            //*******************************************



            if($_GET['qte2'] != 0){

                if($_GET['statut2'] != "BLOQUEE") {
                    $traitees = $_GET['qte2'];
                    $restantes = 0;
                    $etat = "Terminé";
                }
                else {
                    $traitees = 0;
                    $restantes = $_GET['qte2'];
                    $etat = "En cours";
                }

                $palDebut2 = sprintf('%03d', $_GET['palDebut2']);
                $palFin2 = sprintf('%03d', $_GET['palFin2']);
                $lot2 = sprintf('%03d', $_GET['lot2']);

                $statut2 = '<b>'.$_GET['statut2'].' ('.$_GET['qte2'].') : </b> pal. '.$palDebut2.' à '.$palFin2;

                $blocage2 = new Blocage($lot2, $palDebut2, $palFin2, $_GET['qte2'], $etat, $_GET['commentaire'], $_GET['date2'], date('Y-m-d H:i', time()), null, $_SESSION['usr_id'], $_GET['defId'], $_GET['motif'], $traitees, $restantes, $statut2);

                $result2 = $blocageMapper->persist($blocage2);

                if($result2 === false)
                    throw new Exception("Impossible d'enregistrer le blocage (lot n°".$_GET['lot2'].")", 1);

                            // get the last blocage's id
                $blocId = $blocageFinder->findLastBlocageByDef($_GET['defId'])[0];

                if($blocId['bloc_id'] === false)
                    throw new Exception("Impossible de bloquer les palettes", 1);

                $this->blocPal($blocId['bloc_id'], $_GET['lot2'], $_GET['palDebut2'], $_GET['palFin2'], $_GET['statut2']);

                $_SESSION['message'] .="<br/>Palettes n° ".$_GET['palDebut2']." à ".$_GET['palFin2']." (lot ".$_GET['lot2'].") ".$_GET['statut2'];


                // remplissage de la table blocagesHistorique
           
                $hist2 = new BlocagesHistorique(null, $blocId['bloc_id'], $_SESSION['usr_id'], "BLOCAGE", date('Y-m-d H:i', time()), $statut2);

                $result = $blocHistMapper->persist($hist2);

                if($result === false)
                    throw new Exception("Impossible d'enregistrer l'historique");
                

                //*******************************************
            }

            if($_GET['qte3'] != 0){

                if($_GET['statut3'] != "BLOQUEE") {
                    $traitees = $_GET['qte3'];
                    $restantes = 0;
                    $etat = "Terminé";
                }
                else {
                    $traitees = 0;
                    $restantes = $_GET['qte3'];
                    $etat = "En cours";
                }

                $palDebut3 = sprintf('%03d', $_GET['palDebut3']);
                $palFin3 = sprintf('%03d', $_GET['palFin3']);
                $lot3 = sprintf('%03d', $_GET['lot3']);

                $statut3 = '<b>'.$_GET['statut3'].' ('.$_GET['qte3'].') : </b> pal. '.$palDebut3.' à '.$palFin3;

                $blocage3 = new Blocage($lot3, $palDebut3, $palFin3, $_GET['qte3'], $etat, $_GET['commentaire'], $_GET['date3'], date('Y-m-d H:i', time()), null, $_SESSION['usr_id'], $_GET['defId'], $_GET['motif'], $traitees, $restantes, $statut3);

                $result3 = $blocageMapper->persist($blocage3);

                if($result3 === false)
                    throw new Exception("Impossible d'enregistrer le blocage (lot n°".$_GET['lot3'].")", 1);

                            // get the last blocage's id
                $blocId = $blocageFinder->findLastBlocageByDef($_GET['defId'])[0];

                if($blocId['bloc_id'] === false)
                    throw new Exception("Impossible de bloquer les palettes", 1);

                $this->blocPal($blocId['bloc_id'], $_GET['lot3'], $_GET['palDebut3'], $_GET['palFin3'], $_GET['statut3']);

                $_SESSION['message'] .="<br/>Palettes n° ".$_GET['palDebut3']." à ".$_GET['palFin3']." (lot ".$_GET['lot3'].") ".$_GET['statut3'];

                // remplissage de la table blocagesHistorique
           
                $hist3 = new BlocagesHistorique(null, $blocId['bloc_id'], $_SESSION['usr_id'], "BLOCAGE", date('Y-m-d H:i', time()), $statut3);

                $result = $blocHistMapper->persist($hist3);

                if($result === false)
                    throw new Exception("Impossible d'enregistrer l'historique");
                

                //*******************************************
            }

     
            $this->afficherDefautBlocage();

        } 
        catch (Exception $e)
        {
            $_SESSION['message'] = $e->getMessage();

            $this->afficherDefautBlocage();
        }
    }
    
    // Store all palettes bloquées in DB
    private function blocPal($blocId, $lot, $debut, $fin, $statut) {

        $connexion = new Connexion;  
        $paletteMapper = new PaletteMapper($connexion);

        for ($i=$debut; $i <= $fin; $i++) { 

            $i = sprintf('%03d', $i);
            $lot = sprintf('%03d', $lot);

            $palette = new Palette($blocId, $lot, "--", $statut, $i);
            $result = $paletteMapper->persist($palette);

            if($result === false)
                throw new Exception("Impossible de bloquer les palettes", 1);
        }
    }
    /**
     * Met à jour un défaut ou un blocage depuis l'historique en fonction du paramètre reçu en GET
     */
    public function editDefautBlocage()
    {

        $connexion = new Connexion;

        if(isset($_GET['idDefaut'])) {
            $mapper = new DefautMapper($connexion); 
            $id = $_GET['idDefaut'];
        }
        elseif(isset($_GET['idRapport'])) {
            $mapper = new RapportQualiteMapper($connexion); 
            $id = $_GET['idRapport'];
        }
        else {
            $mapper = new BlocageMapper($connexion); 
            $id = $_GET['idBlocage'];
        }


        //Get the field of the table to update it
        $nameBD = $_GET['nameBD'];
        //Get the value that user wants to update
        $elementToUpdate = $_GET['elementToUpdate'];


        try
        {
            $result = $mapper->update($id, htmlspecialchars($elementToUpdate, ENT_QUOTES), $nameBD, date("Y-m-d H:i:s"));

            if($result === false)
                throw new Exception("Impossible d'enregistrer la modification", 1);

            $_SESSION['message'] = "Modification effectuée !";
            
            $this->afficherDefautBlocage();
        }
        catch(Exception $e)
        {
            $_SESSION['message'] = $e->getMessage();

            $this->afficherDefautBlocage();
        }
      
        exit();
    }

    /**
     * Met à jour un défaut ou un blocage en fonction du paramètre reçu en GET
     */
    public function modifierDefautBlocage()
    {

        $connexion = new Connexion;
   
        try
        {

            if(isset($_GET['idDefaut'])) {
               
                $mapper = new DefautMapper($connexion); 
                $id = $_GET['idDefaut'];

                $action = addslashes(preg_replace("/\r\n/",' - ',$_GET['actionCorrective']));
                $origine = addslashes(preg_replace("/\r\n/",' - ',$_GET['origine']));
                $coms = addslashes(preg_replace("/\r\n/",' - ',$_GET['coms']));
                $section = addslashes(preg_replace("/\r\n/",' - ',$_GET['section']));
                $moule = addslashes(preg_replace("/\r\n/",' - ',$_GET['moule']));
                $bague = addslashes(preg_replace("/\r\n/",' - ',$_GET['bague']));
                $secteur = addslashes(preg_replace("/\r\n/",' - ',$_GET['secteur']));
                $sap = $_GET['idSap'];
                $ligne = $_GET['idLig'];
                $usr = $_GET['idUsr'];

                $defaut = new Defaut($id, $secteur, null, $origine, $action, $moule, $bague, $section, null,  $_GET['date'], null, date('Y-m-d H:i', time()), $sap, $ligne, $usr, $coms);

                $result = $mapper->persist($defaut);
             
                if($result === false)
                    throw new Exception("Impossible de modifier le défaut", 1);

                $_SESSION['message'] = "Défaut n° ". $id." modifié !";

                $this->afficherDefautBlocage();
            }

            else {
               
                $mapper = new BlocageMapper($connexion);             
                $blocageFinder = new BlocageFinder($connexion);
                $blocHistMapper = new BlocagesHistoriqueMapper($connexion);

                $id = $_GET['idBlocage'];

                $bloc = $blocageFinder->findBlocageById($id)[0];

                $motif = addslashes(preg_replace("/\r\n/",' - ',$_GET['motif']));
                $coms = addslashes(preg_replace("/\r\n/",' - ',$_GET['coms']));

                $palQte = $_GET['palQte'];
                $palRestantes = $_GET['palRestantes'];
                $palTraitees = $palQte - $palRestantes;

                if($palRestantes == 0)
                    $etatBloc = 'TERMINE'; 
                else
                    $etatBloc = 'En cours';

                $blocEtatPal = $_GET['blocEtatPal'];

                $blocEtatPal = str_replace( "à    /" , "/" , $blocEtatPal);
                

                $paletteFinder = new PaletteFinder($connexion);
                $nbPal = $paletteFinder->countAllPalBloqueesSansDecision($id)['nbPal'];


                // Si une décision a été prise pour une des palettes du blocage, on ajoute un marqueur qui sera utilisé par blocageDatatablesHistorique pour ajouter le mot DECISION OK dans les commentaires. Sinon, on enlève le marqueur s'il existe.
                if($nbPal == 0) {

                    $pos = strpos($coms, '&$');
                    if(!$pos)
                        $coms .= "&$";
                    else
                        $coms = substr($coms, 0, $pos);
                }
       



                $blocage = new Blocage($_GET['lot'], null, null, null, $etatBloc, $coms, $_GET['date'], null, date('Y-m-d H:i', time()), null, null, $_GET['motif'], $palTraitees, $palRestantes, $blocEtatPal, $id);

                $result = $mapper->persist($blocage);
                
                if($result === false)
                    throw new Exception("Impossible de modifier le blocage", 1);

                $date=date_create($_GET['date']);
                $_SESSION['message'] = "Blocage n° ". $id." du " .date_format($date,"d-m-Y H:i")." modifié !";

            
                if($bloc['bloc_pal_statut'] != $blocEtatPal) {

                    // remplissage de la table blocagesHistorique
                

                    $hist = new BlocagesHistorique(null, $id, $_SESSION['usr_id'], "MAJ PAL.", date('Y-m-d H:i', time()),$_GET['blocHist']);

                    $result = $blocHistMapper->persist($hist);

                    if($result === false)
                        throw new Exception("Impossible d'enregistrer l'historique");
                

                    //*******************************************
                }

                if($etatBloc == "TERMINE"){

                    $userFinder = new UtilisateurFinder($connexion);
                    //Déclaration des variables pour envoi d'une notification (effectuée avec ajax après chargement de la page si $_SESSION['mail'] existe)
           
            
                    $_SESSION['mail']['subject'] = 'blocage n°'.$id.' du '.$_GET['date'].' (ligne '.$_GET['numLigne'].') TERMINE';

                    $_SESSION['mail']['mess'] = '<html>'.
                          '<head>'.
                           '<title>REPORTING - Blocage </title>'.
                           '<meta charset=\'UTF-8\'>'.
                          '</head>'.
                          '<body>'.
                            '<h2> Le blocage n° '.$id.' est TERMINE :</h2>'.
                            '<p>'.
                            'Date : '.$_GET['date'].'<br/>'.
                            'Ligne : '. $_GET['numLigne'].'<br/>'.
                            'Sap : '. $_GET['sapNum'].'<br/>'.
                            'Lot : '. $_GET['lot'].'<br/>'.
                            'Nb de palettes : '.$_GET['palQte'].'</p>'.
                          '</body>'.
                        '</html>';

                
                    // Cherche le line leader de la ligne à notifier
                    $usr = $userFinder->findUserBy(array('usr_fk_lig_id' => $_GET['idLigne'], 'fk_usr_fonction1' => 8));

                    $_SESSION['mail']['to'] = "";
                    foreach ($usr as $u) {
                        if($u['usr_mail'] != "")
                            $_SESSION['mail']['to'] .= $u['usr_mail'].',';
                    }
                    $_SESSION['mail']['to'] = substr($_SESSION['mail']['to'], 0, -1);
                }


                // Si le nombre de décisions a évolué, on notifie les concernés pour les avertir d'un changement de desicion
                if($_GET['nbPalSansDecision'] != $nbPal){

                    // remplissage de la table blocagesHistorique
                   
                    $blocHistMapper = new BlocagesHistoriqueMapper($connexion); 

                    $hist = new BlocagesHistorique(null, $id, $_SESSION['usr_id'], "DECISION", date('Y-m-d H:i', time()), 'DECISION RENSEIGNEE');

                    $result = $blocHistMapper->persist($hist);

                    if($result === false)
                        throw new Exception("Impossible d'enregistrer l'historique");
                    

                    //*******************************************
        

                    $userFinder = new UtilisateurFinder($connexion);
                    //Déclaration des variables pour envoi d'une notification (effectuée avec ajax après chargement de la page si $_SESSION['mail'] existe)

                    $_SESSION['mail']['subject'] = 'Décision prise concernant le blocage n°'.$id.' du '.$_GET['date'].' (ligne '.$_GET['numLigne'].')';

                    $_SESSION['mail']['mess'] = '<html>'.
                          '<head>'.
                           '<title>REPORTING - Blocage - Décision</title>'.
                           '<meta charset=\'UTF-8\'>'.
                          '</head>'.
                          '<body>'.
                            '<h2> Une décision a été prise concernant le blocage n°'.$id.' du '.$_GET['date'].' (ligne '.$_GET['numLigne'].')'.' suivant :</h2>'.
                            '<p>'.
                            'Date : '.$_GET['date'].'<br/>'.
                            'Ligne : '. $_GET['numLigne'].'<br/>'.
                            'Nb de palettes : '.$_GET['palQte'].'</p>'.
                          '</body>'.
                        '</html>';

                
                    // Cherche les utilisateurs de type logistique, GQ et ordo à notifier
                    $key = 'fk_usr_fonction1';
                    $values = array(6, 17, 5);

                    $usr = $userFinder->findUserByMultipleValues($key, $values);

                    $_SESSION['mail']['to'] = "";
                    foreach ($usr as $u) {
                        if($u['usr_mail'] != "")
                            $_SESSION['mail']['to'] .= $u['usr_mail'].',';
                    }
                    $_SESSION['mail']['to'] = substr($_SESSION['mail']['to'], 0, -1);

                }

                $this->afficherDefautBlocage();

            }
            
        }
        catch(Exception $e)
        {
            $_SESSION['message'] = $e->getMessage();

            $this->afficherDefautBlocage();
        }
      
    }

    /**
    *   Met à jour l'état d'une palette (utilisé par la fenetre voir/modifier blocage)
    */
    public function ajaxUpdatePalDefautBlocage(){

        $connexion = new Connexion;
        $palMapper = new PaletteMapper($connexion); 
        

        $decision = addslashes(preg_replace("/\r\n/",' - ',$_GET['decision']));
        $etat = addslashes(preg_replace("/\r\n/",' - ',$_GET['etat']));

        $palette = new Palette(null, null, $decision, $etat, null, $_GET['idPal']);

        $result = $palMapper->persist($palette);


        
       
    }

    /**
     * Supprime un défaut ou un blocage en fonction du paramètre reçu en GET
     */
    public function deleteDefautBlocage()
    {
      
        $connexion = new Connexion;

        if(isset($_GET['idDefaut'])) {

            $blocageFinder = new BlocageFinder($connexion); 

            $blocId = $blocageFinder->findLastBlocageByDef($_GET['idDefaut'])[0];

            $mapper = new DefautMapper($connexion); 
            $id = $_GET['idDefaut'];

            if($blocId['bloc_id'])
                throw new Exception("Impossible de supprimer ce défaut, des blocages y sont associés", 1);
        }
        elseif(isset($_GET['idRapport'])) {
            
            $mapper = new RapportQualiteMapper($connexion); 
            
            $id = $_GET['idRapport'];
        }
        else {
            
            $mapper = new BlocageMapper($connexion); 
            
            $id = $_GET['idBlocage'];
        }


        try
        {  

            $result = $mapper->remove($id);
            
            if($result === false)
                throw new Exception("Impossible de supprimer", 1);

            if(isset($_GET['idBlocage'])){
                $blocHistFinder = new BlocagesHistoriqueFinder($connexion);
                $blocHistMapper = new BlocagesHistoriqueMapper($connexion);
              
                $blocHist = $blocHistFinder->findBy(array("blocHist_id" => $id))[0];
                $result2 = $blocHistMapper->remove($blocHist["blocHist_id"]);

                if($result === false)
                    throw new Exception("Blocage supprimé / Impossible de supprimer l'historique associé", 1);
            }

            $_SESSION['message'] = "Suppression effectuée !";
            
            $this->afficherDefautBlocage();
        }
        catch(Exception $e)
        {
            $_SESSION['message'] = $e->getMessage();
            
            $this->afficherDefautBlocage();
        }
        
    }

  
    /**
     * Récupère les défauts connus 
     */
    public function AjaxDefautsconnusDefautBlocage()
    {   

        $connexion = new Connexion;
        $defautsConnusFinder = new DefautsConnusFinder($connexion);

        $json = array();

        //Search defaults categories in dataBase
        if(isset($_GET['go']))
        {
            $listeArticles = $defautsConnusFinder->findAllArticles();

            for($i=0; $i<count($listeArticles); $i++)
            {
                $value = $listeArticles[$i]['defautconnu_article'];
                $json['article'][$i] = utf8_encode($value);
            } 
        }
        //Search defaults categories in dataBase
        elseif(isset($_GET['defautconnu_article'])) 
        {
            $listeCat = $defautsConnusFinder->findAllCategoriesByArticle($_GET['defautconnu_article']);
            $json = $listeCat;
         
        }
        
       
        //Display result in JSON format to treat it in file javascript
        echo json_encode($json);

    }

    
    

    /**
     * Affiche l'historque des blocages et palettes
     */
    public function afficherHistoriqueDefautBlocage()
    {   

        $connexion = new Connexion;
        $blocHistFinder = new BlocagesHistoriqueFinder($connexion);

        try {

            if($_GET['dateDebut'] == "")
                throw new Exception("Merci de choisir une date de début (tableau des blocages) pour consulter l'historique des blocages", 1);
                
            if($_GET['dateFin'] == "")
                $fin = date('Y-m-d H:i', time());
            else
                $fin = $_GET['dateFin'];

            $debut = $_GET['dateDebut'];
            
            $hist = $blocHistFinder->findAllByDate($debut, $fin);


            require('./Views/templates/DefautBlocage/BlocagesHistorique.php');
            
        }
        catch (Exception $e)
        {
            $_SESSION['message'] = $e->getMessage();

            $this->afficherDefautBlocage();
        }

    }

    public function ajaxGetHistoriqueDefautBlocage()
    {   

        $connexion = new Connexion;
        $blocHistFinder = new BlocagesHistoriqueFinder($connexion);

       
        $idBloc = $_GET['idBlocage'];
        
        $hist = $blocHistFinder->findBy(array("blocHist_fk_bloc_id" => $idBloc));

        echo json_encode($hist);
       

    }
 

}
?>

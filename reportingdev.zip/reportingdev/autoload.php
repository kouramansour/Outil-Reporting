<?php

/**
 * This class autoload allows to redirect through all project's architecture to each folders
 * Allows to avoid to fill many require in files => This is a redirection/naivigation class for this project
 * Exemple of use in a file : .... = new nameObject
 * @since 26 août 2016
 * @package ./
 * @author Jordan PROTIN <Jordan.Protin@yahoo.com>
 */
class autoload
{
    private static $_instance = null;

    /**
     * Allows to launch application when user call application's HTTP adress
     * @return Exception or no
     */
    public static function charger()
    {
        if(null !== self::$_instance)
        {
            throw new RuntimeException(sprintf('%s is already started', __CLASS__));
        }

        self::$_instance = new self();

        if(!spl_autoload_register(array(self::$_instance, '_autoload'), false))
        {
            throw RuntimeException(sprintf('%s : Could not start the autoload', __CLASS__));
        }
    }

    /**
     * Allows to shut application 
     * @return Exception or no
     */
    public static function shutDown()
    {
        if(null !== self::$_instance)
        {
            if(!spl_autoload_unregister(array(self::$_instance, '_autoload')))
            {
                throw new RuntimeException('Could not stop the autoload');
            }
            self::$_instance = null;
        }
    }

    /**
     * This is an important function !!
     * Indeed, this allows you to write all folders which are present through REPORTING PROJECT
     * Allows  to know for the application all path to search many informations about each class of application
     * @return path of each folders
     */
    private static function _autoload($class)
    {
        global $rep;
        $filename = $class.'.php';
 
        //You have to write each new folders in this array in order to allows to app to know these path folders
        $dir =array('./',
                    // Controllers
                    'Controleurs/', 'Controleurs/ControleurAdmin/', 'Controleurs/ControleurUser/', 
                    'Controleurs/ControleurVisiteur/', 'Controleurs/SousControleurs/',
                    // Database
                    'Database/',
                    // Librairies
                    'Librairies/',
                    // Models
                    'Models/', 'Models/Authentification/', 'Models/DefautBlocage/', 'Models/Consigne/', 
                    'Models/Acteur/', 'Models/DroitsUtilisateur/', 'Models/Ligne/','Models/Palette/', 'Models/Fonctionnalite/','Models/Defaut/', 'Models/JobChange/', 'Models/JobChange/JobOff/',
                    'Models/JobChange/TTimes/', 'Models/JobChange/Ordonnancement/', 'Models/JobChange/PostJob/',
                    'Models/JobChange/Qualite/', 'Models/PanneEvenement/', 'Models/PlanAction/', 
                    'Models/Sap/', 'Models/CodeForme/', 'Models/Utilisateur/', 'Models/Consigne/',        
                    // Data Cleaning 
                    'ValidationDonnees/', 'ValidationDonnees/Erreur/',
                    // Views
                    'Views/', 'Views/css/', 'Views/img/', 'Views/js/', 'Views/layout/', 'Views/templates/'
                    );
        
		foreach ($dir as $d)
        {
            $file=$rep.$d.$filename; 
		
			if (file_exists($file))
			{
               
				include $file;
			}
        }
    }
}

?>
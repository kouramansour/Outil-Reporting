<?php

session_cache_limiter('private_no_expire, must-revalidate');

/**
 * This class ControleurOrdonnancement allows to manage all module ordonnancement's actions.
 * @since 26 août 2016
 * @package SousControleurs
 * @author Jordan PROTIN <Jordan.Protin@yahoo.com>
 */
class ControleurOrdonnancement 
{

    /**
     * Class's constructor.
     *
     * @return Function[name] Call the good function according action
     */
    public function __construct() 
    {
        $_SESSION['page'] = "job";
    	$tabErreur = array();
        $action = Nettoyage::ClearString($_GET['action']);

        //Check if the user has the necessary rights for this module
        if(!$_SESSION['usr_role'] == "Admin" || !$_SESSION['usr_role'] == "User") 
        { 
            header('Location:./'); 
        }
        
        //By default, first $action called is 'afficherOrdonnancement'
        $this->$action(); 
        exit();	
    }

    /**
     * Allows a user to display the historical scheduling.
     *
     * @return The historical scheduling page
     */
    public function afficherOrdonnancement()
    {   
             
        require('./Views/templates/JobChange/Ordonnancement.php');

        unset($_SESSION['message']);
    }

    

    /**
     * Allows to insert a new recording in BDD's table ordonnancement.
     * @param String $commentaire encoding general comment
     * @param String $commentaireJournee endocing day comment
     * @return Success or Error of insert
     */
    public function persistChangementOrdonnancement()
    {
        $connexion = new Connexion;
        $ordonnancementMapper = new OrdonnancementMapper($connexion);
        
        if ($_GET['idChgt'] == 'null')
            $id = null;
        else
            $id = $_GET['idChgt'];

        try {

            if(empty($_GET['machine']) OR empty($_GET['date']) OR empty( $_GET['idSap']) OR empty($_GET['inputHeureArret'])) 
                throw new Exception("Veuillez remplir tous les champs obligatoires");

            if($_GET['misEnProd'] == 1)
                throw new Exception("Ce changement a déjà eu lieu, il ne peut être modifié !");

            $HeureArret = $_GET['inputHeureArret'].':00';
        
            ///Creation of object Ordonnancement from file Ordonnancement.php which represents entity Ordonnancement
            $changement = new Ordonnancement($_GET['date'], $HeureArret, $_GET['nombreSection'],$_GET['categorieChaud'], $_GET['tempsArche'],$_GET['categorieFroid'], $_GET['commentaire'],  
                                                $_GET['feederiste1'], $_GET['feederiste2'], $_GET['lanceurChaud1'], $_GET['lanceurChaud2'], 
                                                $_GET['lanceurFroid1'], $_GET['lanceurFroid2'], $_GET['anticipationMdc'], 
                                                $_GET['objectifPTPS'], $_GET['objectifJCI'], "", $_GET['typeChangement'], $_GET['idSap'], $_GET['machine'],0,$id );
            

    		//Persist object created
            $res = $ordonnancementMapper->persist($changement);

            if($res === false)
                throw new Exception("Impossible d'enregistrer le changement", 1);

            // Si création d'un changement, on crée les ttimes
            if($id == null) {

                $ordonnancement = new OrdonnancementFinder($connexion);
                $ttimesMapper = new TTimesMapper($connexion);

                //Find last change register to database in order to insert the good id on differents table of dataBase in relation with ordonnancement
                $dernierChangement = $ordonnancement->findChangement($_GET['date'], $HeureArret); 
                $idDernierChangement = $dernierChangement[0]['ordo_id'];  

                //Persist the change into ttimes,postjob,joboff, qualite because they are class jointer in relation with a specific change from ordonnancement
              
                $res2 = $ttimesMapper->saveNewObjectTTimes($idDernierChangement);

                if($res2 === false)
                    throw new Exception("Impossible de créer l'enregistrement TTIMES en BDD", 1);


                $_SESSION['message'] = "Changement bien enregistré!";
            }
            else
                $_SESSION['message'] = "Modifications bien enregistrées!";

            $this->afficherOrdonnancement();
           
        }
        catch(Exception $e) 
        {
            $_SESSION['message'] = $e->getMessage();

            $this->afficherOrdonnancement();
          
        }
    }

   

   
    /**
     * Search all user which has the role $fonction 
     *
     * @return user's id, user's name and user's surname
     */
    public function RechercheUtilisateursOrdonnancement()
    {
        $fonction = $_GET['fonction'];
        $connexion = new Connexion; 
        $utilisateurFinder = new UtilisateurFinder($connexion); 


        $listeUtilisateurs = $utilisateurFinder->findAllByFunction($fonction);
        echo json_encode($listeUtilisateurs);

        return json_encode($listeUtilisateurs);

    }

   

    /**
     * Display the string date according the user's choice for the date for create or update a manufacturing change
     *
     * @return Day in format String
     */
    public function RecuperationJourOrdonnancement()
    {
        $jour = $_GET['date'];
            
        //Display day translated
        echo mb_strtoupper(trim(htmlspecialchars(strftime('%A', strtotime($jour)))), 'UTF-8'); 
    }




  

    /**
     * Allows to delete a manufacturing change from the historical scheduling
     *
     * @return Success or Error of delete
     */
    public function SuppressionChangementOrdonnancement()
    {
        $connexion = new Connexion;
        $ordonnancementMapper = new OrdonnancementMapper($connexion); 
        $ordonnancementFinder = new OrdonnancementFinder($connexion); 
       
        $tTimesMapper = new TTimesMapper($connexion);
        $sapMapper = new SapMapper($connexion);
      
        $chgt = $ordonnancementFinder->findOneById($_GET['idChangement']);

        try
        {
            if($chgt->getMisEnProd() != 1){

                $sapMapper->updateCoupleSapLigneDansLigsap(null, $chgt->getLigne());
                $result = $ordonnancementMapper->remove($chgt->getId());
            

                $_SESSION['message'] = "Changement bien supprimé !";

            }
            else
                $_SESSION['message'] = "Impossible de supprimer ce changement, l'article a déjà été mis en prod.";
            
            $this->afficherOrdonnancement();
        }
        catch(Exception $e) 
        {
            $_SESSION['message'] = $e->getMessage();

            $this->afficherOrdonnancement();
        }
    }


     /**
     * Allows to affect (current production sap) a specific sap
     * Function called from the scheduling ordonnancement
     * @return Success or Error of insert
     */
    public function ajaxAffectationOrdonnancement()
    {

        $connexion = new Connexion; 
        $sapMapper = new SapMapper($connexion); 
        $ordoMapper = new OrdonnancementMapper($connexion);

    
        //Proceed to the sap's affectation when user wants to affect it (current production sap in a specific production line)
        if ($_GET['affectation'] == 1)
        { 
            try
            {
                // Affect the sap to the prod line by setting lap_fk_sap_id in ligsap table
                $result = $sapMapper->updateCoupleSapLigneDansLigsap($_GET['idSap'], $_GET['idLigne']);

                if($result === false)
                    throw new Exception("Impossible d'affecter l'article à la ligne", 1);

                $ordoMapper->mettreEnProd($_GET['ordoId']);


                $_SESSION['message'] = "L'affectation de cet article SAP s'est correctement déroulée !";

                $this->afficherOrdonnancement();

            }
            catch (Exception $e)
            {
                $_SESSION['message'] = $e->getMessage();

                $this->afficherOrdonnancement();
            }
           
        }
       
    }

}
?>

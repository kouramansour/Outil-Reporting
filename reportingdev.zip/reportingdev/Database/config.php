﻿<?php

/**
 * Define all parameters which are necessary in order to connect to the remote database
 * @since 26 août 2016
 * @package Database
 * @author Jordan PROTIN <Jordan.Protin@yahoo.com>
 */


// PHP MAILER
define('MAILUSR', 'automatisme.pgm@o-i.com');
define('MAILPASS', 'gc55jcm67*');
define('MAILHOST', 'smtp-mail.outlook.com');
define('MAILPORT', 587);
define('MAILPROTOCOL', 'STARTTLS');
define('MAILFROM', 'automatisme.pgm@o-i.com');


// HOST
define('DBHOST', '127.0.0.1');
define('DBPORT', '');
define('DBNAME', 'ReportingDev');
define('DBUSER', 'root');
define('DBPASS', 'mysql');

date_default_timezone_set("Europe/paris");
setlocale(LC_ALL,'fr_FR.utf8', 'fra');
?>

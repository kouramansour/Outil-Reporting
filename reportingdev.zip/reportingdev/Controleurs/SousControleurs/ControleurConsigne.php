<?php


session_cache_limiter('private_no_expire, must-revalidate');

require_once("Models/Consigne/ConsigneMapper.php");
require_once("Models/Consigne/Consigne.php");

/**
 * This class ControleurConsigne allows to manage all module consigne's actions.
 * @since 26 août 2016
 * @package SousControleurs
 * @author Jordan PROTIN <Jordan.Protin@yahoo.com>
 */
class ControleurConsigne 
{

    /**
     * Class's constructor.
     *
     * @return Function[name] Call the good function according action
     */
    public function __construct() 
    {
        $_SESSION['page'] = "consignes";
        $tabErreur = array();
        $action = Nettoyage::ClearString($_GET['action']);

        //Check if the user has the necessary rights for this module
        if (!$_SESSION['usr_role'] == "Admin" || !$_SESSION['usr_role'] == "User") 
        { 
            header('Location:./'); 
        }
        
        //By default, first $action called is 'afficherConsigneHistorique' or 'afficherConsigneSaisie'
        $this->$action(); 
        exit();
    }

    /**
     * Allows a user to display the historical plan action page of the application.
     *
     * @return The historical plan action page
     */
    public function afficherConsigneHistorique()
    {
       
      
        require('./Views/templates/Consigne/ConsigneHistorique.php');
    }

    /**
     * Allows a user to display the entry plan action page of the application.
     *
     * @return The entry plan action page
     */
    public function afficherConsigneSaisie()
    {
        require('./Views/templates/Consigne/ConsigneSaisie.php');
    }

    /**
     * Allows to create a new consigne
     * @return Success or Error of insertion
     */
    public function addConsigne()
    {
        $connexion = new Connexion;
        $consigneMapper = new ConsigneMapper($connexion);

        try
        {
            $lines = explode("_",$_GET['ligne']);

            foreach ($lines as $line) {
             
                //Creation of object Consigne from file Consigne.php which represents entity Consigne
                $newConsigne = new Consigne(htmlspecialchars($_GET['commentaireConsigne'], ENT_QUOTES), $_GET['dateConsigne'], NULL, $_GET['dateConsigneFin'], $_SESSION['usr_id'], $line);

                //Persist object created
                $consigneMapper->persist($newConsigne);

            }

          

            echo "Consigne bien enregistrée !";
        }
        catch(Exception $e)
        {
            echo "Erreur : la consigne n'a pas pu être enregistrée au sein de la base de données !";
        }
        exit(); 
    }

    /**
     * When a user wants to delete a recording in BDD's table Consigne.
     *
     * @return Success or Error of delete
     */
    public function deleteConsigne()
    {
        $connexion = new Connexion;
        $consigneMapper = new ConsigneMapper($connexion);

        $tabErreur=array();

        try
        {
            $result = $consigneMapper->remove($_GET['idRecording']);
        }
        catch(Exception $e)
        {
            $tabErreur[]="<font color='red' id='erreur'> La suppression de cette consigne ne s'est pas correctement déroulée !</br>";
            $nbrErreurs++;
            require('./Views/templates/Erreur/erreur.php');
            exit();
        }
        exit();
    }

    /**
     * Allows to update (edit) a specific consigne in historical dataTables from historical consigne view
     * @return Success or Error of update
     */
    public function editHistoriqueConsigne()
    {
        $connexion = new Connexion;
        $consigneMapper = new ConsigneMapper($connexion);
        
        $tabErreur = array();
        $nbrErreurs =0;

        //Get the field of the table to update it
        $nameBD = $_GET['nameBD'];
        //Get the value that user wants to update
        $elementToUpdate = $_GET['elementToUpdate'];

        try
        {
            $result = $consigneMapper->editHistoriqueConsigne($_GET['idRecording'], htmlspecialchars($elementToUpdate, ENT_QUOTES), $nameBD,date("Y-m-d H:i:s"));
        }
        catch(Exception $e)
        {
            $tabErreur[]="<font color='red' id='erreur'> La modification de ce champ a échoué !</br>";
            $nbrErreurs++;
            require('./Views/templates/Erreur/erreur.php');
            exit();
        }
        exit();
    }
}
?>

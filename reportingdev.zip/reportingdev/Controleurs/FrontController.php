<?php

if(empty($_GET)){
  $ModelActor1 = new ModelActor();
  $ModelActor1->deconnexion();
}
    
require_once (__DIR__.'/ControleurVisiteur/ControleurVisiteur.php');

/**
 * This class FrontController allow to manage all routes of the application.
 * Allows to dispatch each route. => TURN EVERY ROAD IN AN ACTION OF A CONTROLLER
 * @since 26 août 2016
 * @package Controleurs
 * @author Jordan PROTIN <Jordan.Protin@yahoo.com>
 */
class FrontController 
{
    
  /**
   * Class's constructor.
   * Register all routes of application
   * @return Controleur[name] Call the good controller according user's function (USER or ADMIN)
   */
  public function __construct()
  {
        
    $ListesActionsCtrlVisitor=array("connexionForm","connexion");

    $UserActions = array_merge($ListesActionsCtrlVisitor,array(
      // MODULE PANNE & EVENT
      'afficherPanneEvenementHistorique','afficherPanneEvenementSaisie','AjaxNiveauxPanneEvenement',
      'updatePanneEvenement','editPanneEvenement','deletePanneEvenement',
      'RechercheUtilisateurFMUPanneEvenement', 'afficherPanneEvenementRapport', 'getStatsPanneEvenement', 'AjaxIdNiveauPanneEvenement',
      // ACTION WHICH REQUIRES NO MODULE 
      'deconnexionCommun','afficherDashboardCommun','ajaxProductionEnCoursCommun','afficherAvisCommun','CreationAvisCommun', 
      'searchUserCommun','recuperationIdSapCommun','searchAllUsersCommun','searchAllLinesCommun','searchDefBlocagesCommun', 'searchAllPaletsCommun', 'ajaxPrevSapCommun',
      //MODULE DEFAUTBLOCAGE
      'afficherDefautBlocage','updateBlocage','modifierDefautBlocage','editDefautBlocage',
      'ajouterDefautBlocage','deleteDefautBlocage', 'bloquerDefautBlocage',
      'RecuperationInfoDefaut','afficherDefautBlocageSaisie', 'AjaxDefautsconnusDefautBlocage', 'ajaxUpdatePalDefautBlocage', 'notifierDefautBlocage', 'exportFicheDecisionDefautBlocage', 'afficherHistoriqueDefautBlocage', 'ajaxGetHistoriqueDefautBlocage', 'afficherDefautBlocageRqSaisie', 'ajouterRqDefautBlocage',
      //MODULE ORDONNANCEMENT [SCHEDULING]
      'afficherOrdonnancement','recuperationCodeArticleOrdonnancement','recuperationIdSapOrdonnancement',
      'recuperationLibelleArticleOrdonnancement','RecuperationInfoOrdonnancement', 'persistChangementOrdonnancement','RechercheUtilisateursOrdonnancement', 'RecuperationJourOrdonnancement', 'SuppressionChangementOrdonnancement', 'ajaxAffectationOrdonnancement',
      //T-TIMES
      'afficherTTimes','updateTTimes','ajaxGetTimeDeltaTTimes',
      
     
      //MODULE SAP 
      'afficherSap','RemoveSap', 'RemoveCfSap','addSap', 'editSap', 'editCfSap', 'ajaxFindAllSap', 'addCfSap', 'AjaxFindAllCfSap' , 'ajaxGetSap' , 'rechercheSap' ,
      //MODULE CONSIGNE
      'afficherConsigneSaisie','addConsigne','afficherConsigneHistorique','deleteConsigne','editHistoriqueConsigne', 
      //MODULE UTILISATEUR
      'afficherGestionUtilisateur','RechercheGestionUtilisateurNonAdmin','updateGestionUtilisateur','editGestionUtilisateur','editMdpGestionUtilisateur', 'saveMdpGestionUtilisateur'
    ));

    //Write all specific administrator's actions
    $AdminActions = array_merge($UserActions,array('afficherGestionUtilisateur', 'RechercheGestionUtilisateurNonAdmin', 
                                                   'updateGestionUtilisateur','editGestionUtilisateur','editMdpGestionUtilisateur',
                                                   'saveMdpGestionUtilisateur'));
      
    $ListeActions = array('User'=>$UserActions,'Admin'=>$AdminActions);
      
    try
    {
	    $ModelActorActual= new ModelActor();
      $ActorActual= $ModelActorActual->getRole();

      if(!isset($_GET['action'])||$_GET['action']==""||$_GET['action']==NULL)
      {  

        $_GET['action']=NULL;
                    
        if($ActorActual==0)
        {
          new ControleurVisiteur();
        }
        else
        {
          $controleur="Controleur".$ModelActorActual->getRole();
          new $controleur();  
        }
      }
      else
      {

        $ActionActual=$_GET['action'];     
           
        if($ActorActual!=null)
        {

          if(in_array($ActionActual,$ListeActions[$ModelActorActual->getRole()]))
          {

				    $controleur="Controleur".$ModelActorActual->getRole();

				    new $controleur(); 
          }
          else
          {

				    $tabErreur []= "<font color='red' size='12'>Une erreur est survenue !!</font>";
				    require('./Views/templates/Erreur/erreur.php');
          }
        }
        else
        {

          if(in_array($ActionActual,$ListesActionsCtrlVisitor))
          {
				    new ControleurVisiteur();
          }
			    $tabErreur []= "<font color='red' size='12'>Une erreur est survenue !!</font>";
			    require('./Views/templates/Erreur/erreur.php');
        } 

      }

    } 
    catch(Exception $ex)
    {
	   $url = "./Views/templates/Erreur/erreur.php?erreur=".$ex->getMessage();
	   header("Location:$url");
    }
  }

  
}
   
